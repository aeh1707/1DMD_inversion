"""Reproducible, versioned neural 1-D magnetotelluric inversion.

These models must be trained with the SI forward solver in ``mt_physics``.
The archived pickle and weights were produced with different physics and are
intentionally incompatible. Resistivity targets are in ohm m; phase is in degrees.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import copy
import math
import random
import warnings

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import StandardScaler

from mt_physics import (
    analytical_forward_model,
    interpolate_mt_response,
    layer_midpoints,
    layer_tops,
)

PHYSICS_VERSION = "mt1d-si-plus-i-v1"
CHECKPOINT_VERSION = 1
FEATURE_SCHEMA = ["log10_apparent_resistivity_ohm_m", "phase_degrees"]


def _positive_integer(value, name, minimum=1):
    if isinstance(value, bool) or int(value) != value or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}.")
    return int(value)


def _thickness_grid(num_layers):
    """Finite layers start at 5 m and sum to 100 km; last layer is a half-space."""
    n = num_layers - 1
    if n == 1:
        return np.array([100_000.0])
    lo, hi = 1.0, 100_000.0 ** (1.0 / (n - 1))
    for _ in range(100):
        ratio = (lo + hi) / 2
        if np.sum(5 * ratio ** np.arange(n)) < 100_000:
            lo = ratio
        else:
            hi = ratio
    return 5 * ((lo + hi) / 2) ** np.arange(n)


def generate_synthetic_data(
    num_samples=10000, num_periods=25, num_layers=47, seed=99, *, noise_level=0.0,
    period_min=1e-3, period_max=1e3,
):
    """Generate independent block/smooth earth priors without reading real labels.

    ``X_data`` contains earth resistivities (samples, layers); ``y_rho`` and
    ``y_phi`` contain their forward responses (samples, periods). This naming
    preserves the original dataset convention. The grid is always explicit.
    Optional lognormal resistivity noise and Gaussian phase noise apply only to
    observations, not targets. Period endpoints can be changed for a new survey;
    doing so requires a freshly trained model and its matching scalers.
    """
    n = _positive_integer(num_samples, "num_samples")
    p = _positive_integer(num_periods, "num_periods", 2)
    layers = _positive_integer(num_layers, "num_layers", 2)
    if not np.isfinite(noise_level) or not 0 <= noise_level < 1:
        raise ValueError("noise_level must lie in [0, 1).")
    if not np.isfinite([period_min, period_max]).all() or not 0 < period_min < period_max:
        raise ValueError("Period endpoints must be finite with 0 < period_min < period_max.")
    rng = np.random.default_rng(seed)
    periods = np.logspace(np.log10(period_min), np.log10(period_max), p)
    thicknesses = _thickness_grid(layers)
    models = np.empty((n, layers))
    rho = np.empty((n, p))
    phase = np.empty((n, p))
    positions = np.arange(layers)
    for i in range(n):
        block_count = int(rng.integers(2, min(layers, 8) + 1))
        cuts = np.sort(rng.choice(np.arange(1, layers), block_count - 1, replace=False))
        bounds = np.r_[0, cuts, layers]
        log_model = np.empty(layers)
        for start, stop in zip(bounds[:-1], bounds[1:]):
            log_model[start:stop] = rng.uniform(-1, 4)
        family = i % 4
        if family == 1:
            # A conductive zone and a resistive surface cap, with variable depths.
            log_model[:] = rng.uniform(1, 3.5)
            centre = rng.uniform(0.2, 0.8) * (layers - 1)
            width = rng.uniform(0.08, 0.25) * layers
            trough = np.exp(-0.5 * ((positions - centre) / width) ** 2)
            log_model -= rng.uniform(1, 3.5) * trough
            log_model[:max(1, int(rng.uniform(0.03, 0.2) * layers))] = rng.uniform(2, 4)
        elif family == 2:
            # Gradational structures supplement sharp blocks without borrowing
            # a supplied reference model or its distribution.
            knots = np.linspace(0, layers - 1, min(layers, 6))
            log_model = np.interp(positions, knots, rng.uniform(-1, 4, len(knots)))
        elif family == 3:
            # Include homogeneous and simple layered cases to anchor the prior.
            if rng.random() < 0.25:
                log_model[:] = rng.uniform(-1, 4)
        log_model = np.clip(log_model, -1, 4)
        models[i] = 10 ** log_model
        rho[i], phase[i] = analytical_forward_model(models[i], thicknesses, 1 / periods)
    if noise_level:
        rho *= np.exp(rng.normal(0, noise_level, rho.shape))
        phase += rng.normal(0, noise_level * 45, phase.shape)
    return {
        "X_data": models,
        "y_rho": rho,
        "y_phi": phase,
        "periods": periods,
        "layer_thicknesses": thicknesses,
        "metadata": {
            "physics_version": PHYSICS_VERSION,
            "seed": int(seed),
            "prior": "independent_loguniform_blocks_caps_troughs_gradients_v1",
            "noise_level": float(noise_level),
            "phase_units": "degrees",
            "resistivity_units": "ohm_m",
            "final_layer": "half_space",
        },
    }


class RecurrentInverter(nn.Module):
    """Each time step is the resistivity/phase pair for one period."""

    def __init__(self, model_type, num_layers, hidden_size1, hidden_size2, dropout):
        super().__init__()
        recurrent = nn.LSTM if model_type == "lstm" else nn.GRU
        self.first = recurrent(2, hidden_size1, batch_first=True)
        self.second = recurrent(hidden_size1, hidden_size2, batch_first=True)
        self.dropout = nn.Dropout(dropout)
        self.output = nn.Linear(hidden_size2, num_layers)

    def forward(self, features):
        sequence, _ = self.first(features)
        sequence, _ = self.second(self.dropout(sequence))
        return self.output(self.dropout(sequence[:, -1]))


class TransformerInverter(nn.Module):
    """Full attention; deterministic in evaluation, unlike random ProbAttention."""

    def __init__(self, num_layers, num_periods, hidden_size1, hidden_size2, dropout):
        super().__init__()
        heads = next(h for h in (4, 2, 1) if hidden_size1 % h == 0)
        self.input = nn.Linear(2, hidden_size1)
        pos = torch.arange(num_periods, dtype=torch.float32)[:, None]
        scale = torch.exp(torch.arange(0, hidden_size1, 2) * (-math.log(10000) / hidden_size1))
        pe = torch.zeros(num_periods, hidden_size1)
        pe[:, 0::2] = torch.sin(pos * scale)
        pe[:, 1::2] = torch.cos(pos * scale[:pe[:, 1::2].shape[1]])
        self.register_buffer("positions", pe[None])
        encoder = nn.TransformerEncoderLayer(
            d_model=hidden_size1, nhead=heads,
            dim_feedforward=max(hidden_size2, hidden_size1), dropout=dropout,
            batch_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder, num_layers=2, enable_nested_tensor=False)
        self.output = nn.Linear(hidden_size1, num_layers)

    def forward(self, features):
        encoded = self.encoder(self.input(features) + self.positions)
        return self.output(encoded.mean(dim=1))


def _make_model(config):
    if config["architecture"] in ("lstm", "gru"):
        return RecurrentInverter(
            config["architecture"], config["num_layers"], config["hidden_size1"],
            config["hidden_size2"], config["dropout"],
        )
    if config["architecture"] == "transformer":
        return TransformerInverter(
            config["num_layers"], config["num_periods"], config["hidden_size1"],
            config["hidden_size2"], config["dropout"],
        )
    raise ValueError(f"Unsupported checkpoint architecture: {config['architecture']!r}.")


def _validate_data(data):
    if data.get("metadata", {}).get("physics_version") != PHYSICS_VERSION:
        raise ValueError(
            "Dataset physics metadata is absent or incompatible. Regenerate with "
            "generate_synthetic_data(); legacy synthetic_data.pkl cannot train corrected models."
        )
    try:
        earth, rho, phase, periods, thicknesses = (
            np.asarray(data[key], dtype=np.float64)
            for key in ("X_data", "y_rho", "y_phi", "periods", "layer_thicknesses")
        )
    except KeyError as error:
        raise ValueError(f"Dataset is missing {error.args[0]!r}.") from error
    if earth.ndim != 2 or len(earth) < 20 or earth.shape[1] < 2:
        raise ValueError("Training requires at least 20 models with at least 2 layers.")
    if periods.ndim != 1 or len(periods) < 2 or np.any(np.diff(periods) <= 0):
        raise ValueError("Dataset periods must be strictly increasing.")
    if rho.shape != phase.shape or rho.shape != (len(earth), len(periods)):
        raise ValueError("Response arrays must have shape (samples, periods).")
    if thicknesses.shape != (earth.shape[1] - 1,):
        raise ValueError("A model with N layers requires N-1 finite thicknesses.")
    if not all(np.all(np.isfinite(a)) for a in (earth, rho, phase, periods, thicknesses)):
        raise ValueError("Training arrays must contain only finite numbers.")
    if any(np.any(a <= 0) for a in (earth, rho, periods, thicknesses)):
        raise ValueError("Resistivities, periods, and finite thicknesses must be positive.")
    return earth, rho, phase, periods, thicknesses


def _features(rho, phase):
    return np.stack([np.log10(rho), phase], axis=-1)


def _seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def train_model(
    synthetic_data, model_type="lstm", epochs=100, batch_size=64,
    learning_rate=0.001, seed=99, hidden_size1=64, hidden_size2=32,
    dropout=0.1, output_dir="artifacts", *, patience=15, device="cpu",
    weight_decay=1e-5, min_delta=1e-6, verbose=True,
):
    """Train on 70/15/15 splits; return the best validation model and metrics.

    Scalers fit the training partition only. Test metrics are computed once after
    restoring the best validation state. No supplied pickle or model is changed.
    ``informer`` is accepted as a migration alias for the full-attention
    ``transformer`` architecture; new checkpoints record that distinction.
    """
    earth, rho, phase, periods, thicknesses = _validate_data(synthetic_data)
    model_type = model_type.lower()
    if model_type not in ("lstm", "gru", "transformer", "informer"):
        raise ValueError("model_type must be lstm, gru, transformer, or informer.")
    if model_type == "informer":
        warnings.warn(
            "'informer' selects the deterministic full-attention transformer; "
            "this is not the paper's ProbSparse Informer architecture.",
            UserWarning, stacklevel=2,
        )
    epochs = _positive_integer(epochs, "epochs")
    batch_size = _positive_integer(batch_size, "batch_size")
    patience = _positive_integer(patience, "patience")
    hidden_size1 = _positive_integer(hidden_size1, "hidden_size1")
    hidden_size2 = _positive_integer(hidden_size2, "hidden_size2")
    if not 0 <= dropout < 1 or learning_rate <= 0 or weight_decay < 0 or min_delta < 0:
        raise ValueError("Invalid dropout, learning_rate, weight_decay, or min_delta.")
    _seed_all(seed)
    rng = np.random.default_rng(seed)
    shuffled = rng.permutation(len(earth))
    end_train, end_val = int(0.7 * len(earth)), int(0.85 * len(earth))
    train_idx, val_idx, test_idx = np.split(shuffled, [end_train, end_val])
    raw_features = _features(rho, phase).reshape(len(earth), -1)
    targets = np.log10(earth)
    x_scaler = StandardScaler().fit(raw_features[train_idx])
    y_scaler = StandardScaler().fit(targets[train_idx])
    x = torch.as_tensor(
        x_scaler.transform(raw_features).reshape(len(earth), len(periods), 2),
        dtype=torch.float32,
    )
    y = torch.as_tensor(y_scaler.transform(targets), dtype=torch.float32)
    config = {
        "architecture": "transformer" if model_type == "informer" else model_type,
        "model_type": model_type, "num_layers": int(earth.shape[1]),
        "num_periods": int(len(periods)), "hidden_size1": hidden_size1,
        "hidden_size2": hidden_size2, "dropout": float(dropout),
    }
    torch_device = torch.device(device)
    model = _make_model(config).to(torch_device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=weight_decay)
    generator = torch.Generator().manual_seed(seed)
    train_loader = DataLoader(
        TensorDataset(x[train_idx], y[train_idx]), batch_size=batch_size,
        shuffle=True, generator=generator, num_workers=0,
    )
    val_loader = DataLoader(
        TensorDataset(x[val_idx], y[val_idx]), batch_size=batch_size,
        shuffle=False, num_workers=0,
    )
    history, best_loss, stale, best_state, best_epoch = [], float("inf"), 0, None, 0
    loss_fn = nn.MSELoss()
    for epoch in range(1, epochs + 1):
        model.train()
        train_sum = 0.0
        for xb, yb in train_loader:
            xb, yb = xb.to(torch_device), yb.to(torch_device)
            optimizer.zero_grad(set_to_none=True)
            loss = loss_fn(model(xb), yb)
            if not torch.isfinite(loss):
                raise RuntimeError("Training produced a non-finite loss; no checkpoint was saved.")
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()
            train_sum += loss.item() * len(xb)
        model.eval()
        with torch.no_grad():
            val_sum = sum(
                loss_fn(model(xb.to(torch_device)), yb.to(torch_device)).item() * len(xb)
                for xb, yb in val_loader
            )
        val_loss = val_sum / len(val_idx)
        history.append({"epoch": epoch, "train_loss": train_sum / len(train_idx), "val_loss": val_loss})
        meaningful_improvement = val_loss < best_loss - min_delta
        if val_loss < best_loss:
            best_loss, best_epoch = val_loss, epoch
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
        stale = 0 if meaningful_improvement else stale + 1
        if verbose and (epoch == 1 or epoch % 10 == 0):
            print(f"{model_type} epoch {epoch}/{epochs}: validation MSE {val_loss:.6g}", flush=True)
        if stale >= patience:
            break
    if best_state is None:
        raise RuntimeError("No finite validation checkpoint was obtained.")
    model.load_state_dict(best_state)
    model.eval()
    with torch.no_grad():
        predictions = np.concatenate([
            model(batch.to(torch_device)).cpu().numpy()
            for batch in x[test_idx].split(batch_size)
        ])
    log_predictions = y_scaler.inverse_transform(predictions)
    residuals = log_predictions - targets[test_idx]
    baseline = targets[train_idx].mean(axis=0)
    metrics = {
        "test_log10_rmse": float(np.sqrt(np.mean(residuals ** 2))),
        "test_log10_mae": float(np.mean(np.abs(residuals))),
        "test_median_multiplicative_error": float(10 ** np.median(np.abs(residuals))),
        "test_prior_mean_log10_rmse": float(np.sqrt(np.mean((targets[test_idx] - baseline) ** 2))),
        "best_validation_loss": float(best_loss), "best_epoch": int(best_epoch),
        "epochs_completed": len(history), "history": history,
        "split_sizes": {"train": len(train_idx), "validation": len(val_idx), "test": len(test_idx)},
    }
    metadata = {
        "physics_version": PHYSICS_VERSION, "feature_schema": FEATURE_SCHEMA.copy(),
        "periods": periods.tolist(), "layer_thicknesses": thicknesses.tolist(),
        "layer_tops": np.asarray(layer_tops(thicknesses)).tolist(),
        "layer_midpoints": np.asarray(layer_midpoints(thicknesses)).tolist(),
        "final_layer": "half_space", "seed": int(seed),
        "data_generation_seed": int(synthetic_data["metadata"].get("seed", seed)),
        "synthetic_seed": int(synthetic_data["metadata"].get("seed", seed)),
        "model_type": model_type, "architecture": config["architecture"],
        "training_prior": str(synthetic_data["metadata"].get("prior", "unspecified")),
        "training_noise_level": float(synthetic_data["metadata"].get("noise_level", 0.0)),
        "training_library_versions": {"numpy": str(np.__version__), "torch": str(torch.__version__)},
    }
    checkpoint = {
        "checkpoint_version": CHECKPOINT_VERSION,
        "model_config": config, "model_state_dict": best_state,
        "metadata": metadata,
        "scalers": {
            "input_mean": torch.from_numpy(x_scaler.mean_.copy()),
            "input_scale": torch.from_numpy(x_scaler.scale_.copy()),
            "target_mean": torch.from_numpy(y_scaler.mean_.copy()),
            "target_scale": torch.from_numpy(y_scaler.scale_.copy()),
        },
        "split_indices": {"train": train_idx.tolist(), "validation": val_idx.tolist(), "test": test_idx.tolist()},
        "training_config": {
            "learning_rate": float(learning_rate), "batch_size": batch_size,
            "patience": patience, "weight_decay": float(weight_decay), "min_delta": float(min_delta),
        },
        "metrics": metrics,
    }
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    checkpoint_path = destination / f"{model_type}_checkpoint.pt"
    temporary = checkpoint_path.with_suffix(".pt.tmp")
    torch.save(checkpoint, temporary)
    temporary.replace(checkpoint_path)
    metrics["checkpoint_path"] = str(checkpoint_path.resolve())
    return model, metrics


@dataclass
class Predictor:
    model: nn.Module
    metadata: dict
    scalers: dict
    device: torch.device
    last_diagnostics: dict = field(default_factory=dict)

    def predict(self, periods, rho, phase):
        rho_in, phase_in = interpolate_mt_response(
            periods, rho, phase, np.asarray(self.metadata["periods"])
        )
        raw = _features(np.asarray(rho_in), np.asarray(phase_in)).reshape(1, -1)
        normalized = (raw - self.scalers["input_mean"]) / self.scalers["input_scale"]
        maximum = float(np.max(np.abs(normalized)))
        self.last_diagnostics = {
            "feature_max_abs_z": maximum,
            "feature_count_abs_z_gt_5": int(np.count_nonzero(np.abs(normalized) > 5)),
            "domain_shift_warning": maximum > 5,
        }
        features = torch.as_tensor(
            normalized.reshape(1, len(self.metadata["periods"]), 2), dtype=torch.float32, device=self.device
        )
        self.model.eval()
        with torch.no_grad():
            scaled = self.model(features).cpu().numpy()[0]
        log_profile = scaled * self.scalers["target_scale"] + self.scalers["target_mean"]
        with np.errstate(over="ignore", under="ignore"):
            profile = 10 ** log_profile
        if not np.all(np.isfinite(profile)) or np.any(profile <= 0):
            raise ValueError("Prediction overflowed; the input is outside this model's usable range.")
        return profile


def _validate_checkpoint(checkpoint):
    if not isinstance(checkpoint, dict) or checkpoint.get("checkpoint_version") != CHECKPOINT_VERSION:
        raise ValueError("Not a corrected versioned checkpoint; retrain with mt_learning.train_model().")
    metadata = checkpoint.get("metadata", {})
    if not isinstance(metadata, dict):
        raise ValueError("Checkpoint metadata must be a dictionary.")
    if metadata.get("physics_version") != PHYSICS_VERSION or metadata.get("feature_schema") != FEATURE_SCHEMA:
        raise ValueError("Incompatible checkpoint physics or feature schema; retrain the model.")
    try:
        config = checkpoint["model_config"]
        n_layers = _positive_integer(config["num_layers"], "checkpoint num_layers", 2)
        n_periods = _positive_integer(config["num_periods"], "checkpoint num_periods", 2)
        for name in ("hidden_size1", "hidden_size2"):
            _positive_integer(config[name], f"checkpoint {name}")
        if not np.isfinite(config["dropout"]) or not 0 <= config["dropout"] < 1:
            raise ValueError("Checkpoint dropout must lie in [0, 1).")
        expected_architecture = "transformer" if config["model_type"] == "informer" else config["model_type"]
        if expected_architecture not in ("lstm", "gru", "transformer") or config["architecture"] != expected_architecture:
            raise ValueError("Checkpoint architecture and model_type are inconsistent.")
        if metadata["architecture"] != config["architecture"] or metadata["model_type"] != config["model_type"]:
            raise ValueError("Checkpoint metadata and model configuration are inconsistent.")
        periods = np.asarray(metadata["periods"], dtype=float)
        thicknesses = np.asarray(metadata["layer_thicknesses"], dtype=float)
        if periods.shape != (n_periods,) or not np.isfinite(periods).all() or np.any(periods <= 0) or np.any(np.diff(periods) <= 0):
            raise ValueError("Checkpoint period grid is invalid or disagrees with model dimensions.")
        if thicknesses.shape != (n_layers - 1,) or not np.isfinite(thicknesses).all() or np.any(thicknesses <= 0):
            raise ValueError("Checkpoint thickness grid is invalid or disagrees with model dimensions.")
        for name, expected in (("layer_tops", layer_tops(thicknesses)), ("layer_midpoints", layer_midpoints(thicknesses))):
            grid = np.asarray(metadata[name], dtype=float)
            if grid.shape != (n_layers,) or not np.isfinite(grid).all() or not np.allclose(grid, expected, rtol=1e-12, atol=1e-12):
                raise ValueError(f"Checkpoint {name} is inconsistent with its thickness grid.")
        if metadata.get("final_layer") != "half_space":
            raise ValueError("Checkpoint final layer must be an infinite half-space.")
        scalers = checkpoint["scalers"]
        for name, size in (("input_mean", 2 * n_periods), ("input_scale", 2 * n_periods), ("target_mean", n_layers), ("target_scale", n_layers)):
            tensor = scalers[name]
            if not isinstance(tensor, torch.Tensor) or tensor.shape != (size,) or not torch.isfinite(tensor).all():
                raise ValueError(f"Checkpoint scaler {name} is invalid or has an incompatible dimension.")
            if name.endswith("scale") and not torch.all(tensor > 0):
                raise ValueError(f"Checkpoint scaler {name} must contain positive values.")
    except (KeyError, TypeError, AttributeError) as error:
        raise ValueError("Checkpoint is missing or has malformed metadata, configuration, or scalers.") from error


def load_predictor(checkpoint, device="cpu"):
    """Load a corrected checkpoint without executing pickle objects."""
    checkpoint = torch.load(checkpoint, map_location="cpu", weights_only=True)
    _validate_checkpoint(checkpoint)
    metadata = checkpoint["metadata"]
    config = checkpoint["model_config"]
    model = _make_model(config)
    model.load_state_dict(checkpoint["model_state_dict"])
    torch_device = torch.device(device)
    model.to(torch_device).eval()
    scalers = {key: value.cpu().numpy() for key, value in checkpoint["scalers"].items()}
    return Predictor(model=model, metadata=copy.deepcopy(metadata), scalers=scalers, device=torch_device)


def predict_checkpoint(path, periods, rho, phase):
    """Return a resistivity vector and the exact grids saved during training."""
    predictor = load_predictor(path)
    profile = predictor.predict(periods, rho, phase)
    metadata = copy.deepcopy(predictor.metadata)
    metadata.update(predictor.last_diagnostics)
    return profile, metadata
