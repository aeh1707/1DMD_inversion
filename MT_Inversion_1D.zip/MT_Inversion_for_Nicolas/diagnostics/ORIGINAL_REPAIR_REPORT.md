# Repair findings and reproducibility limits

This report concerns the files supplied in `MT-DL` and the repository
<https://github.com/aeh1707/1DMD_inversion>. The unchanged local source is
`Corrected_DeepLearning_MT_V2.py`; the repaired entry point is `main.py`.
The original code, synthetic cache, EDI files, reference files, and model
artifacts were preserved. `results/legacy_audit.json` records SHA256 provenance.

## Why changing the function name is insufficient

The upstream README calls `run_prediction()` and promises profile-first tuple
ordering. The supplied source implements `predict_model()` with no return
statement at all. Nicolas's four-variable assignment therefore cannot work with
that exact source. The repaired API provides both historical orders explicitly,
plus `predict_site()` with named fields to remove the ambiguity.

More significant scientific and artifact issues remain behind that API error:

1. **Impedance units.** The supplied SEG EDI impedance values use `(mV/km)/nT`.
   Before calculating `rho_a = |Z|^2 / (mu0 * omega)`, conversion to E/H in ohms
   requires `Z_SI = 1000 * mu0 * Z_EDI`. Omitting it inflates apparent
   resistivity by 633,257.3978, or 5.80 log10 decades. The measurement header
   `UNITS=M` does not change this impedance conversion.
2. **Inconsistent forward signs.** The supplied source combines
   `sqrt(-i * omega * mu0 / rho)` with `+i * omega * mu0 / k`, producing a
   135-degree half-space phase. The repaired convention uses a consistent
   positive imaginary sign and gives exactly the specified resistivity and
   +45-degree phase for a uniform half-space. Independent two-layer and
   limiting-case tests also pass. A reference for the physical convention is
   the [SimPEG MT tutorial](https://github.com/simpeg/tle-magnetotelluric_inversion/blob/master/MTtutorialV0/MTtutorial.tex).
3. **Stale synthetic responses.** The supplied cache contains 100,000 models
   on 25 periods and 47 layers. Recomputing 18 representative models with the
   corrected exact forward calculation gives a mean per-model response RMSE
   of 0.26618 in log10 apparent resistivity and 8.35062 degrees in phase.
   The supplied source's forward function disagrees more strongly in phase
   (mean RMSE about 88.17 degrees). The original generation procedure/noise
   cannot be established from the cache. These are sample checks, not a full
   100,000-model recomputation.
4. **Different comparison responses.** The reference text files say
   `Curve="ZINV"`. Their forward responses fit determinant impedance better
   than either individual XY or YX mode. This supports determinant as the
   default comparison choice; it is an inference, and users can explicitly
   choose XY or YX. Across the full available frequency ranges, reference
   determinant-response RMSEs are 0.01998 log10-rho / 1.68 degrees for 3D01
   and 0.03532 / 3.40 degrees for 3D02.
5. **Evaluation leakage.** The supplied training path automatically fine-tunes
   on all field reference profiles, then predicts those same sites, while
   saving synthetic-validation scores separately. This would not establish
   independent field performance. In the artifacts actually supplied here,
   all named tensors in the base and fine-tuned checkpoints are exactly
   identical for all three architectures. Filenames alone do not establish
   that fine-tuning occurred. The repaired training never reads field labels.
6. **Artifact/configuration mismatch.** The supplied LSTM checkpoint records
   hidden sizes 128/128 and dropout about 0.17305, whereas the paper describes
   256/128 and 0.1. The supplied saved LSTM plot for 3D02 also differs from
   Nicolas's attached screenshot. Their exact source/weights/scalers/cache
   combination is unavailable, so screenshot and paper reproduction are not
   established.

The paper reviewed was `1-s2.0-S2590197426000042-main.pdf`, *Comparison of deep
learning models for 1D magnetotelluric inversion*. This repair does not revise
its reported numbers. Training, scaling, and architecture changes mean that
new results belong to a new experiment.

## What the legacy audit shows

The table evaluates the supplied base checkpoints with the original smoothing
and clipping, at 37 predicted layer midpoints no deeper than the last reference
layer top. Values are RMSE in **log10 resistivity** against the WinGLink
inversion reference. The reference is not independently known ground truth.

| 3D02 supplied model | Original XY preprocessing | Corrected XY | Corrected determinant |
|---|---:|---:|---:|
| LSTM | 0.22659 | 0.63870 | 0.60813 |
| GRU | 0.26503 | 0.43583 | 0.44315 |
| Informer | 0.46795 | 0.48990 | 0.49388 |

**Correcting units alone does not improve these 3D02 profile scores.** A
numerically lower reference error with physically incorrect input scaling is
not evidence that the incorrect scaling is valid. It reinforces the need for
fresh, consistent synthetic generation and training. The audit records
forward-response misfit and feature distribution diagnostics as additional
checks. It resets the original Informer's random evaluation seed for each
case. The repaired legacy compatibility model instead uses deterministic
evaluation sampling, so small Informer differences are expected.

The corrected pipeline does not smooth or clip neural outputs. Its raw neural
scores therefore need not exactly equal the audit's legacy-postprocessed
scores. New experiments and legacy audits should not be combined as though
they shared the same preprocessing, target grid, or training distribution.

## New implementation and experiment

`mt_physics.py` provides validated EDI reading, consistent impedance recursion,
layer mapping, reference sampling and interpolation. It rejects extrapolation,
dimension mismatches, invalid frequencies and nonfinite data; it jointly
removes declared EDI EMPTY rows with a warning.

`mt_learning.py` generates independent broad layered priors and saves versioned
checkpoints. LSTM/GRU inputs are resistivity/phase pairs in increasing period
order. It uses training-only scalers, disjoint 70/15/15 subsets, early stopping,
and the best validation model before one final synthetic test evaluation.
Generation seed and train split seed are saved separately through dataset and
checkpoint metadata. No field-reference profile supplies training labels or
input features.

New `informer` training is explicitly a migration alias for a deterministic
full-attention Transformer, not a replication of ProbSparse attention. Supplied
Informer weights remain available through the legacy path. New neural models
are experimental, not publication-scale validated inversions.

An optional conventional bounded inversion fits log10 apparent resistivity and
phase. `--refine` initializes it from the neural output; `--mode invert` uses a
uniform starting model without neural weights. It penalizes first differences
of log10 layer resistivity, uses fixed illustrative error floors of 0.05 dex
and 3 degrees, and has bounds of 0.01 to 100,000 ohm m. No reference model is
used in its residual or initialization. All exported plots identify which
method produced the curve and show its forward response against measurements.

The conventional physics-only run converged on both sites. On measured
determinant data within the 0.001-1000 s model range it achieved:

| Site | Measurements | log10 apparent-rho RMSE | Phase RMSE (degrees) |
|---|---:|---:|---:|
| 3D01 | 71 | 0.01354 | 1.12449 |
| 3D02 | 61 | 0.03018 | 2.73919 |

These are data fits to the observations used in inversion, not held-out test
scores. Deep resistivity, particularly below the reference depth range,
remains poorly constrained and can vary considerably despite similar data fit.
A small data misfit does not select a unique subsurface model.

Fresh GRU training results and its field comparison are recorded in
`artifacts/gru_training_metrics.json`, `artifacts/gru_checkpoint.pt` and the
corresponding `results/corrected_gru/` outputs. The JSON files give full
precision, checkpoint identity, exact grids and fit status.

The completed demonstration used 10,000 synthetic models, seed 99 for both
generation and splitting, hidden sizes 64/32, dropout 0.1, batch size 128,
learning rate 0.001, AdamW weight decay 0.00001, early-stopping patience 12,
and 80 CPU epochs with two compute threads. Generation and training took
325.19 seconds. Epoch 80 had the best validation loss. The untouched synthetic
test subset contained 1,500 models; its log10 profile RMSE was **0.46318**,
versus **1.31762** for the training-mean profile, with log10 MAE 0.24889.
Training and validation each used 7,000 and 1,500 models respectively.

The following field scores use measured determinant responses within the
training period range. Reference comparisons use the same method but each
model's own depth grid, so they are not exact like-for-like comparisons to
the legacy audit table above.

| Site | Result | log10 apparent-rho RMSE | Phase RMSE (degrees) | log10 reference-profile RMSE |
|---|---|---:|---:|---:|
| 3D01 | Fresh GRU only | 0.12812 | 2.63547 | 0.19676 |
| 3D01 | Fresh GRU + physics | 0.01354 | 1.12443 | 0.18770 |
| 3D02 | Fresh GRU only | 0.12357 | 3.36629 | 0.29582 |
| 3D02 | Fresh GRU + physics | 0.03014 | 2.74114 | 0.23436 |

The fresh neural model captures the conductive trough but still overestimates
near-surface resistivity at 3D02 and has imperfect long-period response fit.
Physics refinement improves data fit; it is a conventional inversion step,
not additional neural test accuracy. Both refinements converged. The field
reference labels were used only for final scoring and plotting. Neither the
new model nor its prior was adjusted in response to those reference scores.

The 25-test suite passed after the final code changes. Only the GRU underwent
this substantive training run; small regression tests exercise LSTM and
Transformer training/inference behavior. They do not establish equivalent
scientific performance for those architectures.

## Validation and recommended use

Run the README commands with the project interpreter. The test suite covers
uniform and two-layer physics, limiting cases, EDI unit/component conversion,
bad data rejection, surface-depth handling, tuple compatibility, reference
independence, scaler/split isolation, checkpoint validation, determinism,
save/reload behavior, known-model inversion and preservation of supplied files.

Use the repaired workflow to conduct a new controlled experiment. An exact
paper reproduction additionally requires the original training revision,
environment, data-generation procedure, split membership and selected model
artifacts. Further scientific validation should include independent field
sites, realistic response noise and uncertainty/depth-of-investigation
analysis. Neither agreement with a WinGLink reference nor a synthetic test
score alone establishes reliable field generalization.
