"""Scientific invariants and parsing checks; run with unittest discovery."""
import tempfile
from pathlib import Path
import unittest
import warnings

import numpy as np

from mt_physics import (
    EDI_TO_OHM, MU0, analytical_forward_model, interpolate_mt_response,
    layer_midpoints, layer_tops, read_edi_file, read_layered_model,
    sample_layered_model,
)


class PhysicsTests(unittest.TestCase):
    def test_halfspace(self):
        frequencies = np.logspace(-5, 5, 31)
        rho, phase = analytical_forward_model([123.4], [], frequencies)
        np.testing.assert_allclose(rho, 123.4, rtol=1e-12)
        np.testing.assert_allclose(phase, 45.0, atol=1e-12)

    def test_two_layer_against_independent_tanh_expression(self):
        frequencies = np.logspace(-4, 4, 25)
        omega = 2 * np.pi * frequencies
        z1 = np.sqrt(1j * omega * MU0 * 10.0)
        z2 = np.sqrt(1j * omega * MU0 * 1000.0)
        q = np.tanh(np.sqrt(1j * omega * MU0 / 10.0) * 70.0)
        expected = z1 * (z2 + z1 * q) / (z1 + z2 * q)
        rho, phase = analytical_forward_model([10.0, 1000.0], [70.0], frequencies)
        np.testing.assert_allclose(rho, np.abs(expected) ** 2 / (MU0 * omega), rtol=1e-11)
        np.testing.assert_allclose(phase, np.angle(expected, deg=True), atol=1e-11)

    def test_uniform_layers_and_extreme_thickness(self):
        rho, phase = analytical_forward_model([50, 50, 50], [1e-5, 1e12], [1e-8, 1e8])
        np.testing.assert_allclose(rho, 50)
        np.testing.assert_allclose(phase, 45)

    def test_forward_rejects_invalid_dimensions_and_values(self):
        for res, th, freq in [([10, 20], [], [1]), ([10], [], [0]), ([-1], [], [1]), ([1, 2], [-1], [1]), ([np.nan], [], [1])]:
            with self.subTest(res=res, th=th, freq=freq), self.assertRaises(ValueError):
                analytical_forward_model(res, th, freq)

    def test_depth_mapping(self):
        np.testing.assert_array_equal(layer_tops([10, 20], 3), [0, 10, 30])
        np.testing.assert_array_equal(layer_midpoints([10, 20], 3), [5, 20, 50])
        np.testing.assert_array_equal(sample_layered_model([0, 9, 10, 29, 30, 1000], [0, 10, 30], [5, 50, 500]), [5, 5, 50, 50, 500, 500])
        with self.assertRaises(ValueError):
            layer_tops([10], 3)

    def test_interpolation_and_extrapolation_rejection(self):
        rho, phase = interpolate_mt_response([100, 1], [1000, 10], [60, 30], [1, 10, 100])
        np.testing.assert_allclose(rho, [10, 100, 1000])
        np.testing.assert_allclose(phase, [30, 45, 60])
        with self.assertRaisesRegex(ValueError, "extrapolation"):
            interpolate_mt_response([1, 10], [10, 20], [45, 45], [0.1, 1])
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            interpolate_mt_response([1, 1], [10, 20], [45, 45], [1])


class EdiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "test.edi"

    def tearDown(self):
        self.tmp.cleanup()

    def write_edi(self, freq=(100, 1), missing=False):
        # Exactly 100 ohm m, +45 degree half-space at two frequencies.
        z = np.sqrt(1j * 2 * np.pi * np.array([100, 1]) * MU0 * 100.0) / EDI_TO_OHM
        sections = {"FREQ": freq, "ZXXR": [0, 0], "ZXXI": [0, 0], "ZXYR": z.real, "ZXYI": z.imag,
                    "ZYXR": -z.real, "ZYXI": -z.imag, "ZYYR": [0, 0], "ZYYI": [0, 0]}
        if missing:
            sections["ZXYR"] = [z.real[0], 1e32]
        content = ">HEAD\nEMPTY=1.0e32\nUNITS=M\n"
        for key, values in sections.items():
            content += f">{key} //{len(values)}\n" + " ".join(f"{v:.16e}" for v in values) + "\n"
        self.path.write_text(content + ">END\n")

    def test_edi_units_and_all_components(self):
        self.write_edi()
        for component in ["xy", "yx", "det"]:
            with self.subTest(component=component):
                periods, rho, phase = read_edi_file(self.path, component=component)
                np.testing.assert_allclose(periods, [0.01, 1])
                np.testing.assert_allclose(rho, 100, rtol=1e-12)
                np.testing.assert_allclose(phase, 45, atol=1e-12)
        _, rho_si, _ = read_edi_file(self.path, impedance_units="si")
        np.testing.assert_allclose(rho_si, 100 / EDI_TO_OHM ** 2)

    def test_empty_rows_are_removed_jointly(self):
        self.write_edi(missing=True)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            periods, rho, phase = read_edi_file(self.path)
        self.assertEqual(len(caught), 1)
        np.testing.assert_allclose(periods, [0.01])
        np.testing.assert_allclose(rho, [100])

    def test_zero_frequency_duplicate_frequency_and_nonfinite(self):
        for freq in [(0, 1), (1, 1), (np.nan, 1)]:
            with self.subTest(freq=freq):
                self.write_edi(freq=freq)
                with self.assertRaises(ValueError):
                    read_edi_file(self.path)

    def test_count_mismatch_and_missing_block(self):
        self.write_edi()
        original = self.path.read_text()
        self.path.write_text(original.replace(">ZXYR //2", ">ZXYR //3"))
        with self.assertRaisesRegex(ValueError, "declares"):
            read_edi_file(self.path)
        self.path.write_text(original.replace(">ZXYI", ">IGNORED"))
        with self.assertRaisesRegex(ValueError, "Missing"):
            read_edi_file(self.path)
        self.path.write_text(original.replace(">FREQ //2\n1.0000000000000000e+02 1.0000000000000000e+00", ">FREQ //1\n1.0000000000000000e+02"))
        with self.assertRaisesRegex(ValueError, "differs"):
            read_edi_file(self.path)

    def test_reference_zero_depth_is_valid(self):
        self.path.write_text('Site="test"\nStartDepth(m) Thickness(m) Rho(ohm.m)\n0 10 100\n10 20 10\n')
        tops, th, rho = read_layered_model(self.path)
        np.testing.assert_array_equal(sample_layered_model([0, 5, 10, 1000], tops, rho), [100, 100, 10, 10])


if __name__ == "__main__":
    unittest.main()
