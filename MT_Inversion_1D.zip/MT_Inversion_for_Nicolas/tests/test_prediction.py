"""Prediction API, independent data fitting, and artifact regression checks."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import mock_open, patch

import numpy as np
import torch

import main
from mt_physics import EDI_TO_OHM, MU0, analytical_forward_model


ROOT = Path(__file__).resolve().parents[1]


def _write_edi(path, periods, profile=(100., 2., 200.), thicknesses=(30., 800.)):
    rho, phase = analytical_forward_model(profile, thicknesses, 1 / periods)
    amplitude = np.sqrt(rho * MU0 * 2 * np.pi / periods) / EDI_TO_OHM
    z = amplitude * np.exp(1j * np.deg2rad(phase))
    sections = {'FREQ': 1 / periods, 'ZXXR': np.zeros(len(z)), 'ZXXI': np.zeros(len(z)),
                'ZXYR': z.real, 'ZXYI': z.imag, 'ZYXR': -z.real, 'ZYXI': -z.imag,
                'ZYYR': np.zeros(len(z)), 'ZYYI': np.zeros(len(z))}
    text = '>HEAD\nEMPTY=1e32\n'
    for key, values in sections.items():
        text += f'>{key} //{len(values)}\n' + ' '.join(f'{v:.17e}' for v in values) + '\n'
    path.write_text(text + '>END\n')
    return rho, phase


class PredictionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.directory = Path(self.tmp.name)
        self.edi = self.directory / 'example.edi'
        self.periods = np.logspace(-3, 3, 25)
        self.rho, self.phase = _write_edi(self.edi, self.periods)
        self.profile = np.array([100., 2., 200.])
        self.metadata = {'periods': self.periods.tolist(), 'layer_thicknesses': [30., 800.],
                         'physics_version': 'test_fixture', 'checkpoint': 'mock'}
        self.reference = self.directory / 'exampleLayered.txt'
        self.reference.write_text('StartDepth(m) Thickness(m) Rho(ohm.m)\n0 30 90\n30 800 3\n830 1000 100\n')

    def tearDown(self):
        self.tmp.cleanup()

    def fake_prediction(self, *args, **kwargs):
        return self.profile.copy(), copy.deepcopy(self.metadata)

    def test_historical_wrapper_return_orders_are_explicit(self):
        result = main.PredictionResult(np.array([0., 10.]), np.array([20., 30.]),
                                       np.array([0., 40.]), np.array([50., 60.]), {})
        with patch.object(main, 'predict_site', return_value=result) as predict:
            email_order = main.predict_model('site.edi', None, 'gru')
            self.assertIs(email_order[0], result.depths)
            self.assertIs(email_order[1], result.profile)
            self.assertIs(email_order[2], result.reference_depths)
            self.assertIs(email_order[3], result.reference_profile)
            predict.assert_called_once_with('site.edi', None, 'gru')
        with patch.object(main, 'predict_site', return_value=result):
            readme_order = main.run_prediction('example', data_dir=self.directory)
            self.assertIs(readme_order[0], result.profile)
            self.assertIs(readme_order[1], result.depths)
            self.assertIs(readme_order[2], result.reference_profile)
            self.assertIs(readme_order[3], result.reference_depths)

    def test_reference_is_optional_and_never_enters_inference(self):
        with patch.object(main, '_legacy_prediction', side_effect=self.fake_prediction) as predict:
            without = main.predict_site(self.edi)
            first_inputs = [value.copy() for value in predict.call_args.args[:3]]
            with_ref = main.predict_site(self.edi, self.reference)
            for expected, actual in zip(first_inputs, predict.call_args.args[:3]):
                np.testing.assert_array_equal(expected, actual)
            # Even replacing every reference resistivity cannot change prediction.
            self.reference.write_text('0 30 1000\n30 800 1000\n830 1000 1000\n')
            changed = main.predict_site(self.edi, self.reference)
        np.testing.assert_array_equal(without.profile, with_ref.profile)
        np.testing.assert_array_equal(without.profile, changed.profile)
        self.assertIsNone(without.reference_profile)
        for result in [without, with_ref, changed]:
            self.assertFalse(result.diagnostics['reference_used_as_input'])
            self.assertEqual(result.diagnostics['result_type'], 'neural_only')
        self.assertIn('not ground truth', with_ref.diagnostics['reference_label'])

    def test_inversion_recovers_known_response_and_improves_fit(self):
        initial = np.full(3, 30.)
        before = main._response_metrics(initial, [30., 800.], self.periods, self.rho, self.phase)
        fitted, info = main.invert_response(self.periods, self.rho, self.phase, [30., 800.],
                                            initial, smoothness=0., max_nfev=150)
        self.assertTrue(info['success'])
        np.testing.assert_allclose(fitted, self.profile, rtol=1e-4)
        self.assertLess(info['response_log10_rho_rmse'], before['response_log10_rho_rmse'] * 1e-3)
        self.assertLess(info['response_phase_rmse_deg'], before['response_phase_rmse_deg'] * 1e-3)
        self.assertEqual(info['method'], 'regularized_1d_least_squares')

    def test_physics_only_has_no_neural_dependency(self):
        with patch.object(main, '_legacy_prediction', side_effect=AssertionError('must not load neural model')):
            # The public API owns a 47-layer grid; mock only optimizer cost here.
            with patch.object(main, 'invert_response', return_value=(np.full(47, 100.), {'method': 'fixture'})):
                result = main.predict_site(self.edi, physics_only=True)
        self.assertEqual(result.diagnostics['result_type'], 'physics_only')
        self.assertNotIn('neural', result.diagnostics)
        self.assertIsNone(result.diagnostics['metadata']['checkpoint'])

    def test_wrong_checkpoint_architecture_is_not_mislabeled(self):
        metadata = copy.deepcopy(self.metadata)
        metadata['model_type'] = 'gru'
        with patch('mt_learning.predict_checkpoint', return_value=(self.profile, metadata)):
            with self.assertRaisesRegex(ValueError, 'model type'):
                main.predict_site(self.edi, checkpoint='gru.pt', model_type='lstm')

    def test_legacy_checkpoint_dimensions_checked_before_model_creation(self):
        (self.directory / 'lstm_checkpoint.pt').touch()
        (self.directory / 'lstm_scalers.pkl').touch()
        config = {'model_type': 'lstm', 'input_size': 50, 'output_size': 3,
                  'hidden_size1': 8, 'hidden_size2': 4, 'dropout': 0.}
        synth = {'periods': self.periods, 'layer_thicknesses': np.array([30., 800.])}
        scalers = {'scaler_input': SimpleNamespace(n_features_in_=50),
                   'scaler_target': SimpleNamespace(n_features_in_=3)}
        cases = [('input_dimension', {'input_size': 49}, None),
                 ('output_dimension', {'output_size': 4}, None),
                 ('architecture', {'model_type': 'gru'}, None),
                 ('scaler_dimension', {}, 49)]
        for name, changes, scaler_dimension in cases:
            with self.subTest(case=name):
                invalid_config = {**config, **changes}
                invalid_scalers = copy.deepcopy(scalers)
                if scaler_dimension:
                    invalid_scalers['scaler_input'].n_features_in_ = scaler_dimension
                with patch.object(main.pickle, 'load', side_effect=[invalid_scalers, synth]), \
                     patch.object(main.Path, 'open', mock_open()), \
                     patch.object(main.torch, 'load', return_value={'config': invalid_config, 'model_state': {}}), \
                     patch('mt_legacy.create_model', side_effect=AssertionError('validation must precede network creation')), \
                     self.assertWarns(UserWarning), self.assertRaises(ValueError):
                    main._legacy_prediction(self.periods, self.rho, self.phase, 'lstm', self.directory)

    def test_outputs_label_provenance_and_preserve_supplied_files(self):
        original_paths = [ROOT / 'Corrected_DeepLearning_MT_V2.py', ROOT / 'synthetic_data.pkl',
                          *sorted((ROOT / 'real_data').glob('*')), *sorted((ROOT / 'models').glob('*/*.pt'))]
        def hashes():
            return {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
                    for path in original_paths if path.is_file()}
        original_hashes = hashes()
        plots = []
        real_subplots = main.plt.subplots
        def record_subplots(*args, **kwargs):
            figure, axes = real_subplots(*args, **kwargs)
            plots.append((figure, axes))
            return figure, axes
        output = self.directory / 'output'
        with patch.object(main, '_legacy_prediction', side_effect=self.fake_prediction), patch.object(main.plt, 'subplots', side_effect=record_subplots):
            result = main.predict_site(self.edi, self.reference, output_dir=output)
        files = {path.suffix: path for path in output.iterdir()}
        self.assertEqual(set(files), {'.csv', '.json', '.png'})
        written = json.loads(files['.json'].read_text())
        self.assertEqual(written['result_type'], 'neural_only')
        self.assertFalse(written['reference_used_as_input'])
        self.assertIn('not ground truth', written['reference_label'])
        self.assertEqual(files['.csv'].read_text().splitlines()[0], 'layer_top_m,resistivity_ohm_m')
        labels = plots[0][1][0].get_legend_handles_labels()[1]
        self.assertIn('Neural prediction', labels)
        self.assertIn('WinGLink reference', labels)
        self.assertNotIn('True Model', labels)
        self.assertEqual(hashes(), original_hashes)
        np.testing.assert_array_equal(result.profile, self.profile)


class CheckpointValidationTests(unittest.TestCase):
    """Reject incompatible artifact grids before broadcasting or network inference."""
    def setUp(self):
        import mt_learning
        self.learning = mt_learning
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / 'checkpoint.pt'
        config = {'architecture': 'lstm', 'model_type': 'lstm', 'num_layers': 3,
                  'num_periods': 3, 'hidden_size1': 8, 'hidden_size2': 4, 'dropout': 0.}
        self.checkpoint = {'checkpoint_version': mt_learning.CHECKPOINT_VERSION,
                           'model_config': config,
                           'model_state_dict': mt_learning._make_model(config).state_dict(),
                           'metadata': {'physics_version': mt_learning.PHYSICS_VERSION,
                                        'feature_schema': mt_learning.FEATURE_SCHEMA.copy(),
                                        'periods': [.001, 1., 1000.], 'layer_thicknesses': [10., 100.],
                                        'layer_tops': [0., 10., 110.],
                                        'layer_midpoints': [5., 60., 210.],
                                        'final_layer': 'half_space',
                                        'model_type': 'lstm', 'architecture': 'lstm'},
                           'scalers': {'input_mean': torch.zeros(6, dtype=torch.float64),
                                       'input_scale': torch.ones(6, dtype=torch.float64),
                                       'target_mean': torch.zeros(3, dtype=torch.float64),
                                       'target_scale': torch.ones(3, dtype=torch.float64)}}

    def tearDown(self):
        self.tmp.cleanup()

    def test_valid_checkpoint_loads(self):
        torch.save(self.checkpoint, self.path)
        predictor = self.learning.load_predictor(self.path)
        self.assertEqual(len(predictor.metadata['periods']), 3)

    def test_incompatible_dimensions_and_scalers_are_rejected(self):
        mutations = {
            'period_length': lambda c: c['metadata'].__setitem__('periods', [.001, 1000.]),
            'thickness_length': lambda c: c['metadata'].__setitem__('layer_thicknesses', [10.]),
            'duplicate_periods': lambda c: c['metadata'].__setitem__('periods', [1., 1., 1000.]),
            'zero_thickness': lambda c: c['metadata'].__setitem__('layer_thicknesses', [0., 100.]),
            'input_scaler_length': lambda c: c['scalers'].__setitem__('input_mean', torch.zeros(5)),
            'target_scaler_length': lambda c: c['scalers'].__setitem__('target_mean', torch.zeros(4)),
            'zero_input_scale': lambda c: c['scalers']['input_scale'].__setitem__(0, 0.),
            'nonfinite_scaler': lambda c: c['scalers']['target_scale'].__setitem__(0, float('nan')),
        }
        for name, mutate in mutations.items():
            with self.subTest(case=name):
                invalid = copy.deepcopy(self.checkpoint)
                mutate(invalid)
                torch.save(invalid, self.path)
                with self.assertRaises(ValueError):
                    self.learning.load_predictor(self.path)


if __name__ == '__main__':
    unittest.main()
