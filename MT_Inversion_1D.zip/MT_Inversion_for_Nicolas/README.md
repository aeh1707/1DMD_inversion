# Corrected 1D MT inversion — Nicolas evaluation bundle

This is a standalone repair and a new GRU experiment based on
[aeh1707/1DMD_inversion](https://github.com/aeh1707/1DMD_inversion).
It includes corrected code, a freshly trained GRU checkpoint, both supplied
field sites, automated checks, and their measured results. It runs without the
original synthetic cache or legacy weights. **It does not establish exact
reproduction of the paper.**

The code now passes its software/physics checks and runs on 3D01 and 3D02.
These two examples are encouraging, but do not establish broad field accuracy
or a uniquely correct subsurface model. See `VALIDATION_AND_LIMITATIONS.md`
before interpreting a result or applying the model to another survey.

## Install

Use Python 3.10 or newer. Extract the entire folder, open a terminal inside it,
and create a new environment; no environment from the developer's computer is
required.

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

If environment activation is disabled by local policy, use
`.\.venv\Scripts\python.exe` instead of `python` in the remaining commands.

Linux/macOS:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

CPU operation is supported. Dependency ranges are in `requirements.txt`;
the versions used for the included training run are also stored in the
checkpoint metadata.
`requirements-tested.txt` pins the five principal libraries used here with
Python 3.12.14; `TESTED_ENVIRONMENT.json` records the full version list. These
versions were tested on Windows; other systems should run the checks below.

## Reproduce the supplied field evaluation

```sh
python -m unittest discover -s tests -v
python main.py --model gru --all-sites
python evaluate_real_data.py
```

The first prediction command runs the neural network alone. The evaluation
script runs it again, also adds the optional physics inversion, checks that
reference profiles do not influence the neural predictions, and verifies that
the data and checkpoint were unchanged. It exits unsuccessfully if any site
fails or a physics fit does not converge.

Look in `results/real_data_test/summary.csv` and `evaluation.json` for the
combined evaluation, and in the PNG/CSV/JSON files beside them for individual
profiles, measured-response fits and diagnostics. These files are already
included; running the evaluation refreshes them. The three-panel figures show
the depth profile, apparent resistivity and phase.

To inspect a single site with optional refinement:

```sh
python main.py --model gru --site 3D02
python main.py --model gru --site 3D02 --refine
```

`--refine` fits the measured MT response with a smooth, bounded conventional
1D inversion initialized by the neural output. Its improved data fit is **not
an additional neural-network accuracy score**. The output is labeled
`neural_plus_physics`. A conventional inversion without the neural network is
also available:

```sh
python main.py --mode invert --all-sites
```

## Use the Python API and resolve the original return-order issue

Use named result fields to avoid ambiguity:

```python
from main import predict_site

result = predict_site(
    "real_data/3D02.edi",
    layered_file="real_data/3D02Layered.txt",  # optional: scoring/plotting only
    model_type="gru",
    checkpoint="artifacts/gru_checkpoint.pt",
    output_dir="results/my_run",
)
depths = result.depths       # layer TOP depths in metres, starting at zero
profile = result.profile    # resistivity in ohm metres; final layer is half-space
print(result.diagnostics)
```

Passing the corrected checkpoint explicitly makes the Python example
unambiguous. Both historical tuple
interfaces are also provided, with their original different orders:

```python
from main import predict_model, run_prediction

# The order in Nicolas's email: depths first.
pred_depths, pred_profile, ref_depths, ref_profile = predict_model(
    "real_data/3D02.edi", "real_data/3D02Layered.txt",
    model_type="gru", checkpoint="artifacts/gru_checkpoint.pt",
)

# The order in the original README: profile first.
pred_profile, pred_depths, ref_profile, ref_depths = run_prediction(
    "3D02", model_type="gru", checkpoint="artifacts/gru_checkpoint.pt",
)
```

References are optional; their result fields are `None` when absent. The
supplied legacy source's prediction function returned nothing. Renaming that
function alone would not resolve the underlying preprocessing and artifact
issues.

## Apply to another dataset

Put compatible EDI files in a separate folder and select that folder:

```sh
python main.py --model gru --all-sites --data-dir new_data --output-dir results/new_data
```

For a single site named `SITE.edi`, use `--site SITE --data-dir new_data`.
A file named `SITELayered.txt` is optional and is used only as an inversion
reference for scoring and plotting.

Before interpreting the output:

- The earth should be reasonably approximated by horizontal 1D layers.
  Strong lateral structure, static shift and other distortions can invalidate
  the assumptions even when the program produces a curve.
- The default determinant mode (`--component det`) requires the full impedance
  tensor. `--component xy` and `--component yx` use individual off-diagonal
  modes; the latter uses `-Zyx`. Check component orientation and phase
  convention. The solver uses `exp(+i omega t)` and a +45-degree homogeneous
  half-space phase. A sign change or phase-quadrant mismatch must be resolved
  consistently before inference.
- Standard SEG EDI impedances are interpreted as `(mV/km)/nT`. Only use
  `--impedance-units si` when the impedance values are E/H in ohms. A header
  such as `UNITS=M` describes measurement geometry, not this conversion.
- Measurements must cover the **entire checkpoint period grid**, currently
  0.001–1000 seconds. Interpolation is allowed; extrapolation is rejected.
  Do not fabricate missing short- or long-period measurements to satisfy it.
- Inspect the predicted forward response against observations, feature
  diagnostics and any physics convergence status. Also compare against an
  independent conventional inversion. Reference agreement alone cannot
  establish correctness.

Retraining is appropriate when the survey's period coverage, depth scale,
resistivity range, geology or noise differs from the training distribution.
It does not by itself make non-1D data compatible with a 1D model. Evaluate
on independent sites that were not used to tune the model or synthetic prior.

## Train a new model

This recreates the included training settings while saving into another
folder, preserving the shipped checkpoint:

```sh
python main.py --mode train --model gru --num-samples 10000 --epochs 80 --patience 12 --seed 99 --artifact-dir artifacts/retrained
python main.py --model gru --all-sites --checkpoint artifacts/retrained/gru_checkpoint.pt
```

The synthetic generator does not read field reference labels or reuse an
original cache. Training uses disjoint 70/15/15 training/validation/test
subsets, training-only scalers, and the best validation checkpoint. The
included demonstration used noise-free synthetic responses.

For observation-noise augmentation, use the Python API, for example:

```python
import torch
from mt_learning import generate_synthetic_data, train_model

torch.set_num_threads(2)
data = generate_synthetic_data(num_samples=10000, seed=99, noise_level=0.05)
model, metrics = train_model(
    data, model_type="gru", epochs=80, batch_size=128,
    patience=12, seed=99, output_dir="artifacts/noise_example",
)
```

Here `noise_level=0.05` adds Gaussian perturbations to the natural logarithm of apparent
resistivity with standard deviation 0.05 and phase with standard deviation
2.25 degrees. This is an illustrative augmentation, not a calibrated error
model for a particular survey.

For another measured period range, retrain with matching coverage; for example:

```sh
python main.py --mode train --model gru --num-samples 10000 --epochs 80 --period-min 0.01 --period-max 100 --num-periods 25 --num-layers 47 --noise-level 0.05 --artifact-dir artifacts_retrained
python main.py --model gru --all-sites --data-dir new_data --checkpoint artifacts_retrained/gru_checkpoint.pt --output-dir results/new_data
```

Here the new data must cover 0.01–100 seconds. Choose the range and noise for
the actual survey, not simply to obtain a favorable fit. The Python generator
also accepts `period_min` and `period_max` keyword arguments.

The CLI can change period coverage, period count, layer count and noise.
Changing the geological prior or finite-layer depth extent requires adapting
`mt_learning.py` (`generate_synthetic_data` and `_thickness_grid`), generating
consistent forward responses, and retraining. The default finite layer tops
span approximately 100 km; changing layer count alone changes discretization,
not that total extent. Do not edit grids or scalers inside an existing
checkpoint: the weights depend on them. New checkpoints record the actual
grids and scaler values. No supervised field fine-tuning helper is included.

Only the new GRU checkpoint is included. LSTM and `informer` require training
new checkpoints; only the GRU has the substantive validation reported here.
New `informer` training is a
full-attention Transformer compatibility alias, **not** the paper's ProbSparse
Informer.

## Bundle contents

- `main.py`, `mt_physics.py`, `mt_learning.py`, `mt_legacy.py`: corrected
  prediction, forward physics, training and compatibility code.
- `evaluate_real_data.py`, `tests/`: repeatable field evaluation and checks.
- `audit_legacy.py`: optional audit requiring the original full artifacts.
- `artifacts/`: new GRU checkpoint and its training metrics.
- `real_data/`: supplied 3D01/3D02 EDI observations and WinGLink references.
- `results/real_data_test/`: included field evaluation and plots.
- `diagnostics/`: recorded legacy audit and archived original source for
  tracing the repair. The original cache and legacy model weights are omitted.
- `VALIDATION_AND_LIMITATIONS.md`: numerical results and scientific limits.

The ordinary GRU commands above need no legacy artifacts. Legacy flags require
the original full artifact set and are not an alternative run path for this
standalone bundle. If the original full project is available, the diagnostic
audit can be rerun against it using `python audit_legacy.py --root PATH_TO_ORIGINAL`.

This bundle addresses the software and API issues raised in the email and
provides a reproducible new experiment for review. Reproducing the published
figures still requires the original training revision, environment, data
generation, split membership and selected artifacts. Nicolas should rerun the
checks in his own environment and compare the exact files he originally used.
