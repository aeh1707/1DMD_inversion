"""Small CPU regression checks; these do not establish geophysical accuracy."""
import copy
from pathlib import Path
import tempfile
import unittest
import warnings

import numpy as np
import torch

from mt_learning import (
    PHYSICS_VERSION,
    generate_synthetic_data,
    load_predictor,
    predict_checkpoint,
    train_model,
)
from mt_physics import analytical_forward_model


class LearningTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)
        cls.data = generate_synthetic_data(40, 8, 5, seed=13)

    def test_generation_seed_and_physics(self):
        same = generate_synthetic_data(40, 8, 5, seed=13)
        different = generate_synthetic_data(40, 8, 5, seed=14)
        self.assertEqual(self.data["metadata"]["physics_version"], PHYSICS_VERSION)
        for key in ("X_data", "y_rho", "y_phi"):
            np.testing.assert_array_equal(self.data[key], same[key])
        self.assertFalse(np.array_equal(self.data["X_data"], different["X_data"]))
        self.assertEqual(len(self.data["layer_thicknesses"]), 4)
        self.assertAlmostEqual(sum(self.data["layer_thicknesses"]), 100_000, places=7)
        self.assertAlmostEqual(self.data["layer_thicknesses"][0], 5)
        rho, phase = analytical_forward_model(
            self.data["X_data"][0], self.data["layer_thicknesses"], 1 / self.data["periods"]
        )
        np.testing.assert_allclose(self.data["y_rho"][0], rho)
        np.testing.assert_allclose(self.data["y_phi"][0], phase)

    def test_unversioned_and_wrong_physics_datasets_are_rejected(self):
        for metadata in ({}, {"physics_version": "legacy"}):
            bad = {**self.data, "metadata": metadata}
            with self.assertRaisesRegex(ValueError, "Regenerate"):
                train_model(bad, epochs=1)

    def test_custom_period_range_and_observation_noise(self):
        clean = generate_synthetic_data(20, 8, 5, seed=13, period_min=.01, period_max=100.)
        noisy = generate_synthetic_data(20, 8, 5, seed=13, period_min=.01, period_max=100., noise_level=.05)
        np.testing.assert_allclose(clean['periods'][[0, -1]], [.01, 100.])
        np.testing.assert_array_equal(clean['X_data'], noisy['X_data'])
        self.assertFalse(np.array_equal(clean['y_rho'], noisy['y_rho']))
        self.assertFalse(np.array_equal(clean['y_phi'], noisy['y_phi']))
        with tempfile.TemporaryDirectory() as directory:
            _, metrics = train_model(noisy, model_type='gru', output_dir=directory,
                                     epochs=1, batch_size=8, hidden_size1=8, hidden_size2=4,
                                     verbose=False)
            predictor = load_predictor(metrics['checkpoint_path'])
            np.testing.assert_array_equal(predictor.metadata['periods'], noisy['periods'])
            self.assertTrue(np.isfinite(predictor.predict(noisy['periods'], noisy['y_rho'][0], noisy['y_phi'][0])).all())
        for lower, upper in [(0., 1.), (1., 1.), (100., .01), (.01, float('nan'))]:
            with self.subTest(period_min=lower, period_max=upper), self.assertRaises(ValueError):
                generate_synthetic_data(20, period_min=lower, period_max=upper)

    def test_best_checkpoint_round_trip_scalers_and_reproducibility(self):
        with tempfile.TemporaryDirectory() as directory:
            options = dict(
                epochs=3, batch_size=10, hidden_size1=8, hidden_size2=4,
                patience=2, seed=7, verbose=False,
            )
            model, metrics = train_model(self.data, output_dir=Path(directory) / "first", **options)
            checkpoint = torch.load(metrics["checkpoint_path"], weights_only=True)
            predictor = load_predictor(metrics["checkpoint_path"])
            self.assertEqual(metrics["split_sizes"], {"train": 28, "validation": 6, "test": 6})
            self.assertEqual(metrics["best_validation_loss"], min(row["val_loss"] for row in metrics["history"]))
            all_indices = sum(checkpoint["split_indices"].values(), [])
            self.assertEqual(sorted(all_indices), list(range(40)))
            train_indices = checkpoint["split_indices"]["train"]
            expected_mean = np.stack(
                [np.log10(self.data["y_rho"]), self.data["y_phi"]], axis=-1
            )[train_indices].reshape(len(train_indices), -1).mean(axis=0)
            np.testing.assert_allclose(predictor.scalers["input_mean"], expected_mean)
            np.testing.assert_allclose(
                predictor.scalers["target_mean"],
                np.log10(self.data["X_data"])[train_indices].mean(axis=0),
            )
            arguments = (self.data["periods"], self.data["y_rho"][0], self.data["y_phi"][0])
            first, metadata = predict_checkpoint(metrics["checkpoint_path"], *arguments)
            np.testing.assert_array_equal(first, predictor.predict(*arguments))
            self.assertTrue(np.isfinite(first).all() and (first > 0).all())
            self.assertEqual(first.shape, (5,))
            self.assertEqual(len(metadata["layer_tops"]), 5)
            self.assertEqual(len(metadata["layer_midpoints"]), 5)
            self.assertEqual(metadata["feature_schema"], ["log10_apparent_resistivity_ohm_m", "phase_degrees"])
            self.assertGreaterEqual(metadata["feature_max_abs_z"], 0)
            for key, expected in model.state_dict().items():
                torch.testing.assert_close(predictor.model.state_dict()[key], expected, rtol=0, atol=0)
            repeated, _ = train_model(self.data, output_dir=Path(directory) / "second", **options)
            for key, expected in model.state_dict().items():
                torch.testing.assert_close(repeated.state_dict()[key], expected, rtol=0, atol=0)
            # An input pair enters a single recurrent time step, never two
            # separate chunks of resistivity and phase pseudo-observations.
            observed_shapes = []
            hook = predictor.model.first.register_forward_pre_hook(
                lambda _, values: observed_shapes.append(tuple(values[0].shape))
            )
            predictor.predict(*arguments)
            hook.remove()
            self.assertEqual(observed_shapes, [(1, 8, 2)])

    def test_all_architectures_evaluate_deterministically(self):
        with tempfile.TemporaryDirectory() as directory:
            for architecture in ("gru", "transformer", "informer"):
                with warnings.catch_warnings(record=True) as captured:
                    warnings.simplefilter("always")
                    _, metrics = train_model(
                        self.data, architecture, epochs=1, batch_size=20,
                        hidden_size1=8, hidden_size2=4, dropout=0.2,
                        output_dir=Path(directory) / architecture, verbose=False,
                    )
                predictor = load_predictor(metrics["checkpoint_path"])
                args = (self.data["periods"], self.data["y_rho"][1], self.data["y_phi"][1])
                np.testing.assert_array_equal(predictor.predict(*args), predictor.predict(*args))
                if architecture == "informer":
                    self.assertEqual(predictor.metadata["architecture"], "transformer")
                    self.assertTrue(any("not the paper" in str(w.message) for w in captured))

    def test_checkpoint_rejects_changed_schema_and_prediction_extrapolation(self):
        with tempfile.TemporaryDirectory() as directory:
            _, metrics = train_model(
                self.data, epochs=1, hidden_size1=4, hidden_size2=4,
                output_dir=directory, verbose=False,
            )
            predictor = load_predictor(metrics["checkpoint_path"])
            with self.assertRaises(ValueError):
                predictor.predict(self.data["periods"][1:], self.data["y_rho"][0, 1:], self.data["y_phi"][0, 1:])
            checkpoint = torch.load(metrics["checkpoint_path"], weights_only=True)
            bad_path = Path(directory) / "bad.pt"
            mutations = [
                lambda c: c["metadata"].update(feature_schema=["legacy_flattened"]),
                lambda c: c["metadata"].update(periods=[1, 2]),
                lambda c: c["metadata"]["periods"].__setitem__(0, float("nan")),
                lambda c: c["metadata"]["layer_thicknesses"].__setitem__(0, -1),
                lambda c: c["metadata"]["layer_tops"].__setitem__(0, 1),
                lambda c: c["model_config"].update(num_layers=6),
                lambda c: c["model_config"].update(architecture="gru"),
                lambda c: c["scalers"].update(input_mean=torch.zeros(2)),
                lambda c: c["scalers"]["target_mean"].__setitem__(0, float("inf")),
                lambda c: c["scalers"]["input_scale"].__setitem__(0, 0),
            ]
            for mutation in mutations:
                bad = copy.deepcopy(checkpoint)
                mutation(bad)
                torch.save(bad, bad_path)
                with self.assertRaises(ValueError):
                    load_predictor(bad_path)


if __name__ == "__main__":
    unittest.main()
