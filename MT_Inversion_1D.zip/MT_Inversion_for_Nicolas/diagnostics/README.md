# Historical diagnosis

These records describe the original full MT-DL folder, before packaging.
Paths in copied JSON records are expressed relative to that original folder.
They are historical identifiers, not claims that every original artifact is
included in this share bundle.

The original V2 source is included here for comparison only. Do not use it as
the corrected entry point; use ../main.py. Its optional dependencies are not
needed by the corrected code.

The original 77 MB synthetic cache, legacy model weights and scalers are not
included. They are not needed for corrected GRU training or prediction.
To repeat the optional legacy audit, obtain the complete original input folder
and run from the share-bundle root:

    python audit_legacy.py --root /path/to/original/full/MT-DL --output /path/to/audit.json

The original repair report is an archival record. For standalone instructions
and current validation, use ../README.md and ../VALIDATION_AND_LIMITATIONS.md.
