"""Validated one-dimensional magnetotelluric data and forward calculations.

EDI impedance is conventionally expressed in (mV/km)/nT. Convert it to E/H
in ohms by multiplying by ``1000 * MU0`` before computing apparent resistivity.
The forward calculation uses the exp(+i omega t) convention, with a homogeneous
half-space phase of +45 degrees. No reference resistivity model is needed to
read data, interpolate observations, or compute a forward response.
"""

from pathlib import Path
import re
import warnings

import numpy as np

MU0 = 4.0 * np.pi * 1e-7
EDI_TO_OHM = 1000.0 * MU0


def _vector(values, name, positive=False, nonnegative=False):
    result = np.asarray(values, dtype=np.float64)
    if result.ndim != 1 or result.size == 0:
        raise ValueError(f"{name} must be a nonempty one-dimensional array")
    if not np.isfinite(result).all():
        raise ValueError(f"{name} contains nonfinite values")
    if positive and np.any(result <= 0):
        raise ValueError(f"{name} must contain strictly positive values")
    if nonnegative and np.any(result < 0):
        raise ValueError(f"{name} cannot contain negative values")
    return result


def _thicknesses(values, n_layers=None):
    result = np.asarray(values, dtype=np.float64)
    if result.ndim != 1 or not np.isfinite(result).all() or np.any(result <= 0):
        raise ValueError("Finite-layer thicknesses must be a positive finite vector")
    if n_layers is not None and len(result) != n_layers - 1:
        raise ValueError(f"Expected {n_layers - 1} finite-layer thicknesses, got {len(result)}")
    return result


def layer_tops(thicknesses, n_layers=None):
    """Return layer top depths, including zero and the half-space top."""
    thicknesses = _thicknesses(thicknesses, n_layers)
    return np.r_[0.0, np.cumsum(thicknesses)]


def layer_midpoints(thicknesses, n_layers=None):
    """Finite-layer centers plus a representative depth for the half-space.

    The last depth is one last finite-layer thickness below its top. A single
    homogeneous half-space has the arbitrary representative depth 1 m.
    """
    thicknesses = _thicknesses(thicknesses, n_layers)
    tops = layer_tops(thicknesses)
    if not len(thicknesses):
        return np.array([1.0])
    return np.r_[tops[:-1] + thicknesses / 2.0, tops[-1] + thicknesses[-1]]


def analytical_forward_model(resistivities, thicknesses, frequencies):
    """Return apparent resistivity (ohm m) and phase (degrees).

    There must be one fewer thickness than resistivity. The final resistivity
    is an infinite half-space. A stable, vectorized reflection recursion avoids
    overflow in hyperbolic functions for thick layers or high frequencies.
    """
    resistivities = _vector(resistivities, "resistivities", positive=True)
    thicknesses = _thicknesses(thicknesses, len(resistivities))
    frequencies = _vector(frequencies, "frequencies", positive=True)
    omega = 2.0 * np.pi * frequencies
    propagation = np.sqrt(1j * omega[:, None] * MU0 / resistivities[None, :])
    intrinsic = np.sqrt(1j * omega[:, None] * MU0 * resistivities[None, :])
    impedance = intrinsic[:, -1].copy()
    for index in range(len(resistivities) - 2, -1, -1):
        reflection = (intrinsic[:, index] - impedance) / (intrinsic[:, index] + impedance)
        attenuation = np.exp(-2.0 * propagation[:, index] * thicknesses[index])
        impedance = intrinsic[:, index] * (1.0 - reflection * attenuation) / (1.0 + reflection * attenuation)
    rho = np.abs(impedance) ** 2 / (MU0 * omega)
    phase = np.rad2deg(np.angle(impedance))
    return rho, phase


def _edi_blocks(content):
    blocks = {}
    # Match complete section names: ZXYR must not also consume ZXYR.EXP.
    pattern = re.compile(r"^\s*>\s*([A-Z][A-Z0-9_.]*)\b([^\r\n]*)[\r\n]+([^>]*)(?=\s*>|\Z)", re.I | re.M)
    for match in pattern.finditer(content):
        name = match.group(1).upper()
        if name == "FREQ" or re.fullmatch(r"Z(?:XX|XY|YX|YY)[RI]", name):
            if name in blocks:
                raise ValueError(f"Duplicate EDI section {name}")
            header, body = match.group(2), match.group(3)
            values = []
            for line in body.splitlines():
                line = line.split("!", 1)[0].strip()
                if not line:
                    continue
                for token in line.split():
                    try:
                        values.append(float(token.replace("D", "E").replace("d", "e")))
                    except ValueError as exc:
                        raise ValueError(f"Invalid number in EDI section {name}: {token!r}") from exc
            count = re.search(r"//\s*(\d+)", header)
            if count and len(values) != int(count.group(1)):
                raise ValueError(f"EDI section {name} declares {count.group(1)} values but contains {len(values)}")
            blocks[name] = np.asarray(values, dtype=np.float64)
    return blocks


def read_edi_file(edi_file, component="xy", impedance_units="edi"):
    """Read a SEG EDI impedance tensor into increasing periods, rho, phase.

    ``component`` is ``xy``, ``yx`` (using -Zyx), or ``det`` (the square root
    of Zxx*Zyy-Zxy*Zyx). ``impedance_units='edi'`` uses (mV/km)/nT;
    ``'si'`` explicitly accepts E/H in ohms. The length unit UNITS=M in an EDI
    measurement header is unrelated to impedance units.

    EMPTY sentinel rows are removed jointly from all requested components with
    a warning. Other nonfinite values, nonpositive frequencies, duplicate
    frequencies, and inconsistent block lengths raise ValueError. Determinant
    phase follows a continuous square-root branch from the highest frequency.
    """
    component = component.lower()
    if component not in {"xy", "yx", "det"}:
        raise ValueError("component must be 'xy', 'yx', or 'det'")
    if impedance_units not in {"edi", "si"}:
        raise ValueError("impedance_units must be 'edi' or 'si'")
    content = Path(edi_file).read_text(encoding="utf-8", errors="replace")
    blocks = _edi_blocks(content)
    if "FREQ" not in blocks:
        raise ValueError(f"No FREQ section in {edi_file}")
    frequencies = _vector(blocks["FREQ"], "EDI frequencies", positive=True)
    requested = ["XX", "XY", "YX", "YY"] if component == "det" else [component.upper()]
    impedance = {}
    sentinel_match = re.search(r"\bEMPTY\s*=\s*([+\-\d.eEdD]+)", content, flags=re.I)
    sentinel = float(sentinel_match.group(1).replace("D", "E").replace("d", "e")) if sentinel_match else 1e32
    valid = np.ones(len(frequencies), dtype=bool)
    for name in requested:
        arrays = []
        for part in ["R", "I"]:
            key = f"Z{name}{part}"
            if key not in blocks:
                raise ValueError(f"Missing EDI section {key} required for component {component}")
            array = blocks[key]
            if len(array) != len(frequencies):
                raise ValueError(f"EDI section {key} length {len(array)} differs from FREQ length {len(frequencies)}")
            if not np.isfinite(array).all():
                raise ValueError(f"EDI section {key} contains nonfinite values")
            valid &= ~np.isclose(array, sentinel, rtol=1e-6, atol=0.0)
            arrays.append(array)
        impedance[name] = arrays[0] + 1j * arrays[1]
    if not valid.all():
        warnings.warn(f"Removed {int((~valid).sum())} EDI rows marked EMPTY for component {component}", RuntimeWarning, stacklevel=2)
    if not valid.any():
        raise ValueError("No valid EDI impedance rows remain")
    periods = 1.0 / frequencies[valid]
    order = np.argsort(periods)
    periods = periods[order]
    if np.any(np.diff(periods) <= 0):
        raise ValueError("Duplicate EDI frequencies are ambiguous; combine them explicitly before inversion")
    impedance = {key: value[valid][order] for key, value in impedance.items()}
    factor = EDI_TO_OHM if impedance_units == "edi" else 1.0
    if component == "det":
        determinant = impedance["XX"] * impedance["YY"] - impedance["XY"] * impedance["YX"]
        phase_radians = 0.5 * np.unwrap(np.angle(determinant))
        z = np.sqrt(np.abs(determinant)) * np.exp(1j * phase_radians) * factor
        phase = np.rad2deg(phase_radians)
    else:
        z = impedance[component.upper()] * factor * (-1.0 if component == "yx" else 1.0)
        phase = np.rad2deg(np.unwrap(np.angle(z)))
    rho = np.abs(z) ** 2 * periods / (2.0 * np.pi * MU0)
    if np.any(rho <= 0) or not np.isfinite(rho).all():
        raise ValueError("EDI data produce zero or nonfinite apparent resistivity")
    return periods, rho, phase


def read_layered_model(layered_file):
    """Read StartDepth(m), Thickness(m), Rho(ohm.m) columns.

    The file's displayed final thickness is preserved. For the forward model
    use ``thicknesses[:-1]``: the final resistivity represents a half-space.
    """
    rows = []
    for number, line in enumerate(Path(layered_file).read_text(encoding="utf-8-sig").splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", "!")):
            continue
        parts = stripped.split()
        try:
            float(parts[0].replace("D", "E").replace("d", "e"))
        except (ValueError, IndexError):
            continue
        if len(parts) != 3:
            raise ValueError(f"Layered model line {number} must contain exactly three columns")
        try:
            rows.append([float(part.replace("D", "E").replace("d", "e")) for part in parts])
        except ValueError as exc:
            raise ValueError(f"Invalid layered model line {number}") from exc
    if not rows:
        raise ValueError(f"No layered model rows in {layered_file}")
    values = np.asarray(rows, dtype=np.float64)
    tops = _vector(values[:, 0], "layer top depths", nonnegative=True)
    thicknesses = _vector(values[:, 1], "layer thicknesses", positive=True)
    resistivities = _vector(values[:, 2], "layer resistivities", positive=True)
    if tops[0] != 0 or np.any(np.diff(tops) <= 0):
        raise ValueError("Layer top depths must start at zero and strictly increase")
    # Exported text rounds depths independently; permit that displayed precision.
    if len(tops) > 1 and not np.allclose(tops[1:], tops[:-1] + thicknesses[:-1], rtol=1e-4, atol=0.002):
        raise ValueError("Layer top depths and thicknesses are inconsistent")
    return tops, thicknesses, resistivities


def sample_layered_model(depths, tops, resistivities):
    """Sample a piecewise constant layered model; extend its final half-space."""
    depths = _vector(depths, "sample depths", nonnegative=True)
    tops = _vector(tops, "layer top depths", nonnegative=True)
    resistivities = _vector(resistivities, "layer resistivities", positive=True)
    if len(tops) != len(resistivities):
        raise ValueError("Layer top and resistivity lengths must match")
    if tops[0] != 0 or np.any(np.diff(tops) <= 0):
        raise ValueError("Layer top depths must start at zero and strictly increase")
    indices = np.searchsorted(tops, depths, side="right") - 1
    return resistivities[indices]


def interpolate_mt_response(periods, rho, phase, target_periods):
    """Interpolate log rho and unwrapped phase in log period, without extrapolation."""
    periods = _vector(periods, "periods", positive=True)
    rho = _vector(rho, "apparent resistivity", positive=True)
    phase = _vector(phase, "phase")
    target_periods = _vector(target_periods, "target periods", positive=True)
    if not len(periods) == len(rho) == len(phase):
        raise ValueError("Period, apparent resistivity, and phase lengths must match")
    if len(periods) < 2:
        raise ValueError("At least two observations are required for interpolation")
    order = np.argsort(periods)
    periods, rho, phase = periods[order], rho[order], phase[order]
    if np.any(np.diff(periods) <= 0):
        raise ValueError("Duplicate periods are ambiguous")
    tolerance = 1e-10
    if target_periods.min() < periods[0] * (1.0 - tolerance) or target_periods.max() > periods[-1] * (1.0 + tolerance):
        raise ValueError(f"Requested periods [{target_periods.min():g}, {target_periods.max():g}] exceed observed coverage [{periods[0]:g}, {periods[-1]:g}]; extrapolation is disabled")
    target_log = np.log10(target_periods)
    period_log = np.log10(periods)
    rho_in = 10.0 ** np.interp(target_log, period_log, np.log10(rho))
    phase_in = np.interp(target_log, period_log, np.rad2deg(np.unwrap(np.deg2rad(phase))))
    return rho_in, phase_in
