"""Reproducible 1D MT prediction, training and optional physics inversion.

Corrected training writes versioned artifacts under artifacts/. Older supplied
weights can be evaluated explicitly through the optional legacy pathway.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
import pickle
import warnings

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import least_squares
import torch

from mt_physics import (analytical_forward_model, read_edi_file,
                        read_layered_model, layer_tops, layer_midpoints,
                        sample_layered_model, interpolate_mt_response)

ROOT = Path(__file__).resolve().parent


@dataclass
class PredictionResult:
    depths: np.ndarray
    profile: np.ndarray
    reference_depths: np.ndarray | None
    reference_profile: np.ndarray | None
    diagnostics: dict


def _response_metrics(profile, thicknesses, periods, rho, phase):
    calculated_rho, calculated_phase = analytical_forward_model(profile, thicknesses, 1 / periods)
    return {'response_log10_rho_rmse': float(np.sqrt(np.mean((np.log10(calculated_rho / rho)) ** 2))),
            'response_phase_rmse_deg': float(np.sqrt(np.mean((calculated_phase - phase) ** 2)))}


def invert_response(periods, rho, phase, thicknesses, initial_profile=None,
                    smoothness=0.3, max_nfev=150):
    """Smooth, bounded least-squares fit to measurements; no reference labels.

    Fixed error floors are 0.05 log10-rho and 3 degrees, not measured errors.
    This is an optional conventional inversion, not a neural-network result.
    """
    periods, rho, phase, thicknesses = map(lambda a: np.asarray(a, dtype=float),
                                         (periods, rho, phase, thicknesses))
    if (periods.ndim != 1 or rho.shape != periods.shape or phase.shape != periods.shape
            or len(periods) < 2 or np.any(periods <= 0) or np.any(rho <= 0)
            or not all(np.isfinite(a).all() for a in (periods, rho, phase))):
        raise ValueError('Finite positive periods/rho and matching phase arrays are required.')
    if not np.isfinite(smoothness) or smoothness < 0 or max_nfev < 1:
        raise ValueError('smoothness must be nonnegative and max_nfev positive.')
    n = len(thicknesses) + 1
    layer_tops(thicknesses, n)
    if initial_profile is None:
        initial_profile = np.full(n, np.median(rho))
    initial_profile = np.asarray(initial_profile, dtype=float)
    if initial_profile.shape != (n,) or np.any(initial_profile <= 0) or not np.isfinite(initial_profile).all():
        raise ValueError('Initial profile must contain one positive resistivity per layer.')

    def residual(log_profile):
        r, p = analytical_forward_model(10.0 ** log_profile, thicknesses, 1 / periods)
        data = np.r_[np.log10(r / rho) / 0.05, (p - phase) / 3.0]
        # A first difference also penalizes unconstrained deep ramps. Second
        # differences alone have a linear null space that can run to bounds.
        return np.r_[data, np.sqrt(smoothness) * np.diff(log_profile)]

    fit = least_squares(residual, np.clip(np.log10(initial_profile), -2, 5),
                        bounds=(-2, 5), max_nfev=max_nfev, ftol=1e-8, xtol=1e-8, gtol=1e-8)
    result = 10.0 ** fit.x
    return result, {'method': 'regularized_1d_least_squares', 'success': bool(fit.success),
                    'message': fit.message, 'nfev': fit.nfev, 'smoothness': smoothness,
                    'regularization': 'first_difference_log10_resistivity',
                    'assumed_log10_rho_error': 0.05, 'assumed_phase_error_deg': 3.0,
                    **_response_metrics(result, thicknesses, periods, rho, phase)}


def _legacy_prediction(periods, rho, phase, model_type, model_dir=None, finetuned=False):
    """Load only the explicitly selected supplied model; warn about provenance."""
    from mt_legacy import create_model
    directory = Path(model_dir) if model_dir else ROOT / 'models' / model_type.upper()
    suffix = '_finetuned' if finetuned else ''
    checkpoint_path = directory / f'{model_type}_checkpoint{suffix}.pt'
    scaler_path = directory / f'{model_type}_scalers.pkl'
    if not checkpoint_path.is_file() or not scaler_path.is_file():
        raise FileNotFoundError(f'Model/scalers missing in {directory}; train a new model first.')
    warnings.warn('Using unversioned supplied weights: corrected inputs cannot establish exact paper reproduction.', UserWarning)
    if finetuned:
        warnings.warn('Supplied fine-tuned weights used field reference labels; these sites are not independent tests.', UserWarning)
    # These are the user-supplied local artifacts. New artifacts do not use pickle scalers.
    with scaler_path.open('rb') as f:
        scalers = pickle.load(f)
    with (ROOT / 'synthetic_data.pkl').open('rb') as f:
        synth = pickle.load(f)
    checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=True)
    config = checkpoint['config']
    if config['model_type'] != model_type:
        raise ValueError('Requested model type does not match the supplied checkpoint.')
    grid = np.asarray(synth['periods'])
    thicknesses = np.asarray(synth['layer_thicknesses'])
    expected_input, expected_output = 2 * len(grid), len(thicknesses) + 1
    if config['input_size'] != expected_input or config['output_size'] != expected_output:
        raise ValueError('Supplied checkpoint does not match the synthetic period/depth grids.')
    if (scalers['scaler_input'].n_features_in_ != expected_input
            or scalers['scaler_target'].n_features_in_ != expected_output):
        raise ValueError('Supplied scaler dimensions do not match the checkpoint grids.')
    model = create_model(config['model_type'], config['input_size'], config['output_size'],
                         config['hidden_size1'], config['hidden_size2'], config['dropout'])
    model.load_state_dict(checkpoint['model_state'])
    model.eval()
    r, p = interpolate_mt_response(periods, rho, phase, grid)
    features = np.r_[np.log10(r), p][None, :]
    scaled = scalers['scaler_input'].transform(features)
    with torch.inference_mode():
        predicted = model(torch.as_tensor(scaled, dtype=torch.float32)).numpy()
    log_profile = scalers['scaler_target'].inverse_transform(predicted)[0]
    profile = 10.0 ** log_profile
    if not np.isfinite(profile).all() or np.any(profile <= 0):
        raise ValueError('Checkpoint produced invalid resistivities; retrain with versioned physics.')
    return profile, {'periods': grid.tolist(), 'layer_thicknesses': synth['layer_thicknesses'].tolist(),
                     'checkpoint': str(checkpoint_path), 'physics_version': 'unversioned_supplied',
                     'finetuned': finetuned, 'feature_max_abs_z': float(np.abs(scaled).max()),
                     'feature_count_abs_z_gt_5': int((np.abs(scaled) > 5).sum())}


def predict_site(edi_file, layered_file=None, model_type='lstm', *, component='det',
                 impedance_units='edi', checkpoint=None, model_dir=None, finetuned=False,
                 legacy=False, refine=False, physics_only=False, output_dir=None, smoothness=0.3):
    """Predict using EDI only, then optionally evaluate a layered reference.

    Returns named fields to avoid the two historical tuple orders. With no new
    checkpoint supplied, first look for artifacts/<model>_checkpoint.pt. The
    optional legacy path uses original base weights in models/<MODEL>/.
    """
    if checkpoint is not None and (legacy or finetuned or model_dir is not None):
        raise ValueError('A corrected checkpoint cannot be combined with legacy model options.')
    candidate = ROOT / 'artifacts' / f'{model_type}_checkpoint.pt'
    if checkpoint is None and not (legacy or finetuned or model_dir is not None or physics_only) and candidate.is_file():
        checkpoint = candidate
    periods, rho, phase = read_edi_file(edi_file, component=component, impedance_units=impedance_units)
    if physics_only:
        grid = np.logspace(-3, 3, 25)
        thicknesses = 5.0 * 1.2 ** np.arange(46)
        profile = None
        metadata = {'periods': grid.tolist(), 'layer_thicknesses': thicknesses.tolist(),
                    'physics_version': 'mt1d-si-plus-i-v1', 'checkpoint': None}
    elif checkpoint:
        from mt_learning import predict_checkpoint
        profile, metadata = predict_checkpoint(checkpoint, periods, rho, phase)
        if metadata['model_type'] != model_type:
            raise ValueError('Requested model type does not match the corrected checkpoint.')
        grid = np.asarray(metadata['periods'])
        thicknesses = np.asarray(metadata['layer_thicknesses'])
        metadata['checkpoint'] = str(Path(checkpoint).resolve())
    else:
        profile, metadata = _legacy_prediction(periods, rho, phase, model_type, model_dir, finetuned)
        grid = np.asarray(metadata['periods'])
        thicknesses = np.asarray(metadata['layer_thicknesses'])

    # Evaluate the same range as network input, at the actual measured periods.
    mask = (periods >= grid.min()) & (periods <= grid.max())
    t, r, p = periods[mask], rho[mask], phase[mask]
    if len(t) < 2:
        raise ValueError('Insufficient measured periods in the model range.')
    diagnostics = {'site': Path(edi_file).stem, 'component': component,
                   'impedance_units': impedance_units, 'model_type': model_type,
                   'period_range_s': [float(t.min()), float(t.max())],
                   'n_observations': len(t), 'reference_used_as_input': False,
                   'metadata': metadata}
    raw_profile = None if profile is None else profile.copy()
    if raw_profile is not None:
        diagnostics['neural'] = _response_metrics(profile, thicknesses, t, r, p)
    if refine or physics_only:
        profile, fit = invert_response(t, r, p, thicknesses, profile, smoothness=smoothness)
        diagnostics['physics_fit'] = fit
    diagnostics['result_type'] = ('physics_only' if physics_only else 'neural_plus_physics' if refine else 'neural_only')
    diagnostics.update(_response_metrics(profile, thicknesses, t, r, p))
    tops = layer_tops(thicknesses, len(profile))
    reference_tops, reference_rho = None, None
    if layered_file is not None:
        reference_tops, _, reference_rho = read_layered_model(layered_file)
        mid = layer_midpoints(thicknesses, len(profile))
        # Compare where finite reference layers are tabulated; do not score the
        # arbitrarily extended halfspace as though its depth were constrained.
        overlap = (mid >= reference_tops[0]) & (mid <= reference_tops[-1])
        diagnostics['reference_comparison_layers'] = int(overlap.sum())
        diagnostics['reference_label'] = 'WinGLink inversion reference (not ground truth)'
        if overlap.any():
            expected = sample_layered_model(mid[overlap], reference_tops, reference_rho)
            diagnostics['reference_log10_rho_rmse'] = float(np.sqrt(np.mean(np.log10(profile[overlap] / expected) ** 2)))
            if raw_profile is not None:
                diagnostics['neural']['reference_log10_rho_rmse'] = float(np.sqrt(np.mean(np.log10(raw_profile[overlap] / expected) ** 2)))
        else:
            diagnostics['reference_log10_rho_rmse'] = None
    result = PredictionResult(tops, profile, reference_tops, reference_rho, diagnostics)
    if output_dir is not None:
        _save_outputs(result, raw_profile, thicknesses, t, r, p, output_dir)
    return result


def _save_outputs(result, raw_profile, thicknesses, periods, rho, phase, output_dir):
    directory = Path(output_dir)
    directory.mkdir(parents=True, exist_ok=True)
    d = result.diagnostics
    stem = f"{d['site']}_{d['model_type']}_{d['component']}_{d['result_type']}"
    np.savetxt(directory / f'{stem}_profile.csv', np.c_[result.depths, result.profile],
               delimiter=',', header='layer_top_m,resistivity_ohm_m', comments='')
    with (directory / f'{stem}_metrics.json').open('w') as f:
        json.dump(d, f, indent=2, allow_nan=False)
    fig, axes = plt.subplots(1, 3, figsize=(16, 5), constrained_layout=True)
    ax = axes[0]
    # Plot a finite representative segment of the bottom halfspace; hide z=0
    # on a log axis by starting at a small positive depth, not dropping layer 1.
    def step(tops, profile, **kwargs):
        x = np.r_[tops, max(tops[-1] * 1.5, 1.)]
        x[0] = min(1., x[1] / 2)
        ax.step(x, np.r_[profile, profile[-1]], where='post', **kwargs)
    if raw_profile is not None and d['result_type'] == 'neural_plus_physics':
        step(result.depths, raw_profile, label='Neural prediction', color='tab:orange', alpha=.7)
    label = {'neural_only': 'Neural prediction', 'neural_plus_physics': 'Neural + physics fit',
             'physics_only': 'Conventional physics inversion'}[d['result_type']]
    step(result.depths, result.profile, label=label, color='tab:blue')
    if result.reference_depths is not None:
        step(result.reference_depths, result.reference_profile, label='WinGLink reference', color='black', linestyle='--')
    ax.set(xscale='log', yscale='log', xlabel='Depth (m)', ylabel='Resistivity (ohm m)')
    fitted_rho, fitted_phase = analytical_forward_model(result.profile, thicknesses, 1 / periods)
    axes[1].loglog(periods, rho, 'k.', label='Measured')
    axes[1].loglog(periods, fitted_rho, label='Result forward response')
    axes[1].set(xlabel='Period (s)', ylabel='Apparent resistivity (ohm m)')
    axes[2].semilogx(periods, phase, 'k.', label='Measured')
    axes[2].semilogx(periods, fitted_phase, label='Result forward response')
    axes[2].set(xlabel='Period (s)', ylabel='Phase (degrees)')
    for a in axes:
        a.legend(fontsize=8)
        a.grid(True, which='both', alpha=.25)
    fig.suptitle(f"{d['site']} | {d['component'].upper()} | {label}")
    fig.savefig(directory / f'{stem}.png', dpi=150)
    plt.close(fig)


def predict_model(edi_file, layered_file=None, model_type='lstm', **kwargs):
    """Email-era API: (pred_depths, pred_profile, reference_depths, reference_profile)."""
    result = predict_site(edi_file, layered_file, model_type, **kwargs)
    return result.depths, result.profile, result.reference_depths, result.reference_profile


def run_prediction(site, model_type='lstm', data_dir=None, **kwargs):
    """README API: (pred_profile, pred_depths, reference_profile, reference_depths)."""
    directory = Path(data_dir) if data_dir else ROOT / 'real_data'
    reference = directory / f'{site}Layered.txt'
    result = predict_site(directory / f'{site}.edi', reference if reference.is_file() else None, model_type, **kwargs)
    return result.profile, result.depths, result.reference_profile, result.reference_depths


def cli():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['predict', 'train', 'both', 'invert'], default='predict')
    parser.add_argument('--model', choices=['lstm', 'gru', 'informer', 'all'], default='gru')
    parser.add_argument('--site', default='3D02')
    parser.add_argument('--all-sites', action='store_true')
    parser.add_argument('--component', choices=['det', 'xy', 'yx'], default='det')
    parser.add_argument('--impedance-units', choices=['edi', 'si'], default='edi')
    parser.add_argument('--checkpoint', type=Path)
    parser.add_argument('--legacy', action='store_true', help='Explicitly use original base weights even if a new model exists')
    parser.add_argument('--finetuned', action='store_true', help='Explicitly use supplied fine-tuned weights; field results are not independent tests')
    parser.add_argument('--refine', action='store_true', help='Fit measured MT response after neural prediction')
    parser.add_argument('--smoothness', type=float, default=.3)
    parser.add_argument('--data-dir', type=Path, default=ROOT / 'real_data')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'results')
    parser.add_argument('--artifact-dir', type=Path, default=ROOT / 'artifacts')
    parser.add_argument('--num-samples', type=int, default=10000)
    parser.add_argument('--num-periods', type=int, default=25)
    parser.add_argument('--period-min', type=float, default=.001, help='Minimum training period in seconds')
    parser.add_argument('--period-max', type=float, default=1000., help='Maximum training period in seconds')
    parser.add_argument('--num-layers', type=int, default=47)
    parser.add_argument('--noise-level', type=float, default=0., help='Synthetic observation noise level (0 to <1)')
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--patience', type=int, default=15, help='Epochs without validation improvement before stopping')
    parser.add_argument('--batch-size', type=int, default=128)
    parser.add_argument('--seed', type=int, default=99)
    parser.add_argument('--threads', type=int, default=2, help='CPU compute threads')
    args = parser.parse_args()
    if args.threads < 1:
        parser.error('--threads must be positive')
    torch.set_num_threads(args.threads)
    if args.checkpoint and (args.legacy or args.finetuned or args.model == 'all'):
        parser.error('--checkpoint cannot be combined with --legacy, --finetuned or --model all')
    models = ['lstm', 'gru', 'informer'] if args.model == 'all' else [args.model]
    for model_type in models:
        checkpoint = args.checkpoint
        if args.mode in ('train', 'both'):
            from mt_learning import generate_synthetic_data, train_model
            synthetic = generate_synthetic_data(num_samples=args.num_samples, seed=args.seed,
                                                num_periods=args.num_periods, num_layers=args.num_layers,
                                                noise_level=args.noise_level, period_min=args.period_min,
                                                period_max=args.period_max)
            _, metrics = train_model(synthetic, model_type=model_type, epochs=args.epochs,
                                     batch_size=args.batch_size, seed=args.seed, output_dir=args.artifact_dir,
                                     patience=args.patience)
            checkpoint = Path(metrics['checkpoint_path'])
            print(json.dumps({k: v for k, v in metrics.items() if k != 'history'}, indent=2))
        if args.mode in ('predict', 'both', 'invert'):
            candidate = args.artifact_dir / f'{model_type}_checkpoint.pt'
            if checkpoint is None and candidate.is_file() and not (args.legacy or args.finetuned):
                checkpoint = candidate
            files = sorted(args.data_dir.glob('*.edi')) if args.all_sites else [args.data_dir / f'{args.site}.edi']
            for edi in files:
                ref = edi.with_name(f'{edi.stem}Layered.txt')
                result = predict_site(edi, ref if ref.is_file() else None, model_type,
                                      component=args.component, impedance_units=args.impedance_units,
                                      checkpoint=checkpoint, finetuned=args.finetuned, legacy=args.legacy, refine=args.refine,
                                      physics_only=args.mode == 'invert', output_dir=args.output_dir,
                                      smoothness=args.smoothness)
                print(json.dumps({k: v for k, v in result.diagnostics.items() if k != 'metadata'}, indent=2))


if __name__ == '__main__':
    cli()
