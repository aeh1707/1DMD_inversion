"""Weight-compatible architectures for the supplied, unversioned checkpoints.

Extracted from Corrected_DeepLearning_MT_V2.py. Evaluation key sampling is
deterministic; parameter names and tensor shapes are unchanged.
"""
import math
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size1=128, hidden_size2=64, dropout=0.1, output_size=None):
        super(LSTMModel, self).__init__()
        self.lstm1 = nn.LSTM(input_size=1, hidden_size=hidden_size1, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        self.lstm2 = nn.LSTM(input_size=hidden_size1, hidden_size=hidden_size2, batch_first=True)
        self.dropout2 = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_size2, output_size)
        
    def forward(self, x):
        x = x.unsqueeze(2)
        x, _ = self.lstm1(x)
        x = self.dropout1(x)
        x, _ = self.lstm2(x)
        x = self.dropout2(x)
        x = x[:, -1, :] 
        x = self.fc(x)
        return x

class GRUModel(nn.Module):
    def __init__(self, input_size, hidden_size1=128, hidden_size2=64, dropout=0.1, output_size=None):
        super(GRUModel, self).__init__()
        self.gru1 = nn.GRU(input_size=1, hidden_size=hidden_size1, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        self.gru2 = nn.GRU(input_size=hidden_size1, hidden_size=hidden_size2, batch_first=True)
        self.dropout2 = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_size2, output_size)
        
    def forward(self, x):
        x = x.unsqueeze(2)
        x, _ = self.gru1(x)
        x = self.dropout1(x)
        x, _ = self.gru2(x)
        x = self.dropout2(x)
        x = x[:, -1, :]
        x = self.fc(x)
        return x

class PositionalEmbedding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super(PositionalEmbedding, self).__init__()
        pe = torch.zeros(max_len, d_model).float()
        pe.requires_grad = False
        position = torch.arange(0, max_len).float().unsqueeze(1)
        div_term = (torch.arange(0, d_model, 2).float() * -(math.log(10000.0) / d_model)).exp()
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        return self.pe[:, :x.size(1)]

class ProbMask():
    def __init__(self, B, H, L, index, scores, device="cpu"):
        _mask = torch.ones(L, scores.shape[-1], dtype=torch.bool).to(device).triu(1)
        _mask_ex = _mask[None, None, :].expand(B, H, L, scores.shape[-1])
        indicator = _mask_ex[torch.arange(B, device=device)[:, None, None],
                             torch.arange(H, device=device)[None, :, None],
                             index, :].to(device)
        self.mask = indicator.view(scores.shape).to(device)

class ProbAttention(nn.Module):
    def __init__(self, mask_flag=True, factor=5, scale=None, attention_dropout=0.1, output_attention=False):
        super(ProbAttention, self).__init__()
        self.factor = factor
        self.scale = scale
        self.mask_flag = mask_flag
        self.output_attention = output_attention
        self.dropout = nn.Dropout(attention_dropout)

    def _prob_QK(self, Q, K, sample_k, n_top):
        B, H, L_Q, D = Q.shape
        _, _, L_K, _ = K.shape
        index_sample = (torch.randint(L_K, (L_Q, sample_k), device=Q.device) if self.training else ((torch.arange(L_Q, device=Q.device)[:, None] + torch.arange(sample_k, device=Q.device)[None, :] * max(1, L_K // sample_k)) % L_K)) 
        K_expand = K.unsqueeze(-3).expand(B, H, L_Q, L_K, D)
        K_sample = K_expand[:, :, torch.arange(L_Q).unsqueeze(1), index_sample, :]
        Q_K_sample = torch.matmul(Q.unsqueeze(-2), K_sample.transpose(-2, -1)).squeeze(-2)
        M = Q_K_sample.max(-1)[0] - torch.div(Q_K_sample.sum(-1), L_K)
        M_top = M.topk(n_top, sorted=False)[1]
        
        Q_reduce = Q[torch.arange(B, device=Q.device)[:, None, None], 
                     torch.arange(H, device=Q.device)[None, :, None], 
                     M_top, :] 
        
        Q_K = torch.matmul(Q_reduce, K.transpose(-2, -1))
        return Q_K, M_top

    def _get_initial_context(self, V, L_Q):
        B, H, L_V, D = V.shape
        if not self.mask_flag:
            V_sum = V.mean(dim=-2)
            contex = V_sum.unsqueeze(-2).expand(B, H, L_Q, V_sum.shape[-1]).clone()
        else:
            assert (L_Q == L_V)
            contex = V.cumsum(dim=-2)
        return contex

    def _update_context(self, context_in, V, scores, index, L_Q):
        B, H, L_V, D = V.shape
        if self.mask_flag:
            attn_mask = ProbMask(B, H, L_Q, index, scores, device=V.device)
            scores.masked_fill_(attn_mask.mask, -np.inf)
        attn = torch.softmax(scores, dim=-1)
        
        context_in[torch.arange(B, device=V.device)[:, None, None],
                   torch.arange(H, device=V.device)[None, :, None],
                   index, :] = torch.matmul(attn, V).type_as(context_in)
                   
        if self.output_attention:
            attns = (torch.ones([B, H, L_V, L_V]) / L_V).type_as(attn).to(attn.device)
            attns[torch.arange(B, device=attn.device)[:, None, None], 
                  torch.arange(H, device=attn.device)[None, :, None], 
                  index, :] = attn
            return context_in, attns
        else:
            return context_in, None

    def forward(self, queries, keys, values):
        B, L_Q, H, D = queries.shape
        _, L_K, _, _ = keys.shape
        queries = queries.transpose(2, 1)
        keys = keys.transpose(2, 1)
        values = values.transpose(2, 1)
        U_part = self.factor * np.ceil(np.log(L_K)).astype('int').item()
        u = self.factor * np.ceil(np.log(L_Q)).astype('int').item()
        U_part = U_part if U_part < L_K else L_K
        u = u if u < L_Q else L_Q
        scores_top, index = self._prob_QK(queries, keys, u, U_part)
        scale = self.scale or 1. / sqrt(D)
        if scale is not None:
            scores_top = scores_top * scale
        context = self._get_initial_context(values, L_Q)
        context, attn = self._update_context(context, values, scores_top, index, L_Q)
        return context.transpose(2, 1).contiguous(), attn

class AttentionLayer(nn.Module):
    def __init__(self, attention, d_model, n_heads, d_keys=None, d_values=None):
        super(AttentionLayer, self).__init__()
        d_keys = d_keys or (d_model // n_heads)
        d_values = d_values or (d_model // n_heads)
        self.inner_attention = attention
        self.query_projection = nn.Linear(d_model, d_keys * n_heads)
        self.key_projection = nn.Linear(d_model, d_keys * n_heads)
        self.value_projection = nn.Linear(d_model, d_values * n_heads)
        self.out_projection = nn.Linear(d_values * n_heads, d_model)
        self.n_heads = n_heads

    def forward(self, queries, keys, values):
        B, L, _ = queries.shape
        _, S, _ = keys.shape
        H = self.n_heads
        queries = self.query_projection(queries).view(B, L, H, -1)
        keys = self.key_projection(keys).view(B, S, H, -1)
        values = self.value_projection(values).view(B, S, H, -1)
        out, attn = self.inner_attention(queries, keys, values)
        out = out.view(B, L, -1)
        return self.out_projection(out), attn

class EncoderLayer(nn.Module):
    def __init__(self, attention, d_model, d_ff=None, dropout=0.1, activation="relu"):
        super(EncoderLayer, self).__init__()
        d_ff = d_ff or 4 * d_model
        self.attention = attention
        self.conv1 = nn.Conv1d(in_channels=d_model, out_channels=d_ff, kernel_size=1)
        self.conv2 = nn.Conv1d(in_channels=d_ff, out_channels=d_model, kernel_size=1)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = F.relu if activation == "relu" else F.gelu

    def forward(self, x):
        new_x, attn = self.attention(x, x, x)
        x = x + self.dropout(new_x)
        y = x = self.norm1(x)
        y = self.dropout(self.activation(self.conv1(y.transpose(-1, 1))))
        y = self.dropout(self.conv2(y).transpose(-1, 1))
        return self.norm2(x + y), attn

class InformerModel(nn.Module):
    def __init__(self, input_size, d_model=128, n_heads=8, e_layers=3, d_ff=256, dropout=0.0, output_size=None):
        super(InformerModel, self).__init__()
        self.embedding = nn.Linear(1, d_model)
        self.pos_emb = PositionalEmbedding(d_model)
        self.encoder_layers = nn.ModuleList([
            EncoderLayer(
                AttentionLayer(
                    ProbAttention(False, 5, attention_dropout=dropout, output_attention=False),
                    d_model, n_heads),
                d_model, d_ff, dropout=dropout, activation="gelu"
            ) for _ in range(e_layers)
        ])
        self.dropout = nn.Dropout(dropout)
        self.layer_norm = nn.LayerNorm(d_model)
        self.fc = nn.Linear(d_model, output_size)
        
    def forward(self, x):
        x = x.unsqueeze(2)
        x = self.embedding(x)
        x += self.pos_emb(x)
        for enc_layer in self.encoder_layers:
            x, attn = enc_layer(x)
        x = self.layer_norm(x)
        x = torch.mean(x, dim=1)
        x = self.fc(x)
        return x

def create_model(model_type, input_size, output_size, hidden_size1=128, hidden_size2=64, dropout=0.2):
    model_classes = {'lstm': LSTMModel, 'gru': GRUModel, 'informer': InformerModel}
    if model_type not in model_classes:
        raise ValueError(f"Unknown model type: {model_type}")
    
    model_class = model_classes[model_type]
    
    if model_type == 'informer':
        n_heads = 4
        if hidden_size1 % n_heads != 0:
            hidden_size1 = (hidden_size1 // n_heads) * n_heads

        model = model_class(
            input_size=input_size, d_model=hidden_size1, n_heads=n_heads, e_layers=2,
            d_ff=hidden_size2*4, dropout=dropout, output_size=output_size
        )
    else:
        model = model_class(
            input_size=input_size, hidden_size1=hidden_size1, hidden_size2=hidden_size2,
            dropout=dropout, output_size=output_size
        )
    return model
