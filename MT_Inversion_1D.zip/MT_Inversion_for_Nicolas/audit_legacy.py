"""Audit supplied research artifacts without changing or training them.

Loads only the explicitly supplied local pickle/checkpoint files. The original
network definitions are extracted without importing its training entry point.
Reference inversions are read for reporting after each prediction, never as
network input. Run: .venv/Scripts/python.exe audit_legacy.py
"""
from __future__ import annotations

import argparse
import ast
import cmath
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import pickle
import platform
import re

import numpy as np
from scipy.signal import savgol_filter
import torch
from torch import nn
from torch.nn import functional as F

import mt_physics as physics


def original_definitions(source_path: Path) -> dict:
    """Compile architecture and two original math/parser functions only."""
    source = ast.parse(source_path.read_text(encoding="utf-8-sig"))
    names = {
        "LSTMModel", "GRUModel", "PositionalEmbedding", "ProbMask",
        "ProbAttention", "AttentionLayer", "EncoderLayer", "InformerModel",
        "create_model", "read_edi_file", "analytical_forward_model",
    }
    selected = [node for node in source.body
                if isinstance(node, (ast.ClassDef, ast.FunctionDef))
                and node.name in names]
    namespace = {"np": np, "torch": torch, "nn": nn, "F": F,
                 "math": math, "sqrt": math.sqrt, "re": re, "cmath": cmath}
    exec(compile(ast.Module(body=selected, type_ignores=[]),
                 str(source_path), "exec"), namespace)
    return namespace


def sha256(path: Path) -> dict:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return {"path": str(path.resolve()), "bytes": path.stat().st_size,
            "sha256": digest.hexdigest()}


def array_summary(values) -> dict:
    a = np.asarray(values)
    finite = a[np.isfinite(a)]
    return {"shape": list(a.shape), "dtype": str(a.dtype),
            "nonfinite_count": int(np.sum(~np.isfinite(a))),
            "min": float(np.min(finite)) if finite.size else None,
            "max": float(np.max(finite)) if finite.size else None,
            "mean": float(np.mean(finite)) if finite.size else None,
            "std": float(np.std(finite)) if finite.size else None}


def response_metrics(pred_rho, pred_phi, observed_rho, observed_phi) -> dict:
    valid = (np.isfinite(pred_rho) & np.isfinite(observed_rho)
             & np.isfinite(pred_phi) & np.isfinite(observed_phi)
             & (pred_rho > 0) & (observed_rho > 0))
    if not np.any(valid):
        return {"valid_count": 0}
    dr = np.log10(np.asarray(pred_rho)[valid] / np.asarray(observed_rho)[valid])
    dp = np.asarray(pred_phi)[valid] - np.asarray(observed_phi)[valid]
    return {"valid_count": int(np.sum(valid)),
            "log10_rho_rmse": float(np.sqrt(np.mean(dr ** 2))),
            "phase_rmse_deg": float(np.sqrt(np.mean(dp ** 2))),
            "normalized_rms_5pct_rho_2deg_phase": float(np.sqrt(np.mean(
                np.concatenate((dr / np.log10(1.05), dp / 2.0)) ** 2)))}


def audit_synthetic(synth: dict, original: dict, sample_count: int) -> dict:
    total = len(synth["X_data"])
    selected = np.unique(np.concatenate((
        [0, min(99, total-1), min(12345, total-1)],
        np.linspace(0, total-1, sample_count, dtype=int))))
    comparisons = []
    for index in selected:
        model = synth["X_data"][index]
        rho, phase = physics.analytical_forward_model(
            model, synth["layer_thicknesses"], 1 / synth["periods"])
        old_rho, old_phase = original["analytical_forward_model"](
            model, synth["layer_thicknesses"], 1 / synth["periods"])
        comparisons.append({"index": int(index),
                            "corrected_exact": response_metrics(
                                rho, phase, synth["y_rho"][index], synth["y_phi"][index]),
                            "supplied_v2_function": response_metrics(
                                old_rho, old_phase, synth["y_rho"][index], synth["y_phi"][index])})
    halfspace = original["analytical_forward_model"]([100.0], [], [1.0])
    corrected = physics.analytical_forward_model([100.0], [], [1.0])
    return {"arrays": {k: array_summary(v) for k, v in synth.items()},
            "log10_model_resistivity": array_summary(np.log10(synth["X_data"])),
            "saved_phase_outside_0_90_count": int(np.sum(
                (synth["y_phi"] <= 0) | (synth["y_phi"] >= 90))),
            "grid_layer_count": int(synth["X_data"].shape[1]),
            "grid_finite_thickness_count": len(synth["layer_thicknesses"]),
            "grid_base_depth_m": float(np.sum(synth["layer_thicknesses"])),
            "sample_comparisons": comparisons,
            "halfspace_100ohmm_1hz": {
                "supplied_v2_rho": float(halfspace[0][0]),
                "supplied_v2_phase_deg": float(halfspace[1][0]),
                "corrected_rho": float(corrected[0][0]),
                "corrected_phase_deg": float(corrected[1][0])}}


def field_curves(site_path: Path, train_periods, original: dict):
    curves = {}
    summaries = {}
    for name, component, legacy in [
            ("original_xy", "xy", True),
            ("corrected_xy", "xy", False),
            ("corrected_det", "det", False),
            ("corrected_yx", "yx", False)]:
        try:
            if legacy:
                period, rho, phase = original["read_edi_file"](site_path)
            else:
                period, rho, phase = physics.read_edi_file(site_path, component=component)
            grid_rho, grid_phase = physics.interpolate_mt_response(
                period, rho, phase, train_periods)
            curves[name] = (grid_rho, grid_phase)
            summaries[name] = {"native_periods": array_summary(period),
                               "native_apparent_rho": array_summary(rho),
                               "native_phase_deg": array_summary(phase),
                               "grid_apparent_rho": grid_rho.tolist(),
                               "grid_phase_deg": grid_phase.tolist()}
        except Exception as error:
            summaries[name] = {"error": f"{type(error).__name__}: {error}"}
    if "original_xy" in curves and "corrected_xy" in curves:
        ratio = curves["original_xy"][0] / curves["corrected_xy"][0]
        summaries["original_to_corrected_xy_rho_ratio"] = array_summary(ratio)
    return curves, summaries


def evaluate_checkpoint(checkpoint_path: Path, scalers: dict, curves: dict,
                        reference: tuple, synth: dict, original: dict) -> dict:
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
    config = checkpoint["config"]
    model = original["create_model"](
        config["model_type"], config["input_size"], config["output_size"],
        config["hidden_size1"], config["hidden_size2"], config["dropout"])
    model.load_state_dict(checkpoint["model_state"])
    model.eval()
    state_nonfinite = {name: int(torch.sum(~torch.isfinite(value)).item())
                       for name, value in checkpoint["model_state"].items()
                       if torch.is_floating_point(value) and not torch.isfinite(value).all()}
    state_digest = hashlib.sha256()
    for name, value in sorted(checkpoint["model_state"].items()):
        state_digest.update(name.encode("utf-8"))
        state_digest.update(str(value.dtype).encode("ascii"))
        state_digest.update(str(tuple(value.shape)).encode("ascii"))
        state_digest.update(value.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes())
    result = {"provenance": sha256(checkpoint_path), "config": config,
              "parameter_count": sum(p.numel() for p in model.parameters()),
              "state_tensor_sha256": state_digest.hexdigest(),
              "nonfinite_state_values": state_nonfinite,
              "evaluation_seed": 99, "cases": {}}
    h = synth["layer_thicknesses"]
    mids = physics.layer_midpoints(h)
    tops, ref_h, ref_rho = reference
    # The export's final thickness is a display choice for a half-space. Avoid
    # using it to enlarge the domain on which a reference profile is scored.
    reference_bottom = float(tops[-1])
    overlap = (mids >= tops[0]) & (mids <= reference_bottom)
    reference_sample = physics.sample_layered_model(mids[overlap], tops, ref_rho)
    for name, (rho, phase) in curves.items():
        features = np.hstack((np.log10(rho), phase)).reshape(1, -1)
        scaled = scalers["scaler_input"].transform(features)
        ood = {"feature_z_abs_max": float(np.max(np.abs(scaled))),
               "feature_abs_z_gt_5_count": int(np.sum(np.abs(scaled) > 5)),
               "resistivity_abs_z_gt_5_count": int(np.sum(np.abs(scaled[0, :len(rho)]) > 5)),
               "phase_abs_z_gt_5_count": int(np.sum(np.abs(scaled[0, len(rho):]) > 5))}
        torch.manual_seed(99)  # Original Informer samples keys even in eval mode.
        with torch.no_grad():
            pred_scaled = model(torch.as_tensor(scaled, dtype=torch.float32)).numpy()
        pred_log = scalers["scaler_target"].inverse_transform(pred_scaled)[0]
        case = {"input_distribution": ood,
                "unprocessed_predicted_log10_resistivity": array_summary(pred_log)}
        if not np.isfinite(pred_log).all():
            case["error"] = "Supplied checkpoint produced nonfinite outputs; no clipping or scoring applied."
            result["cases"][name] = case
            continue
        # Reproduce original prediction postprocessing for the baseline.
        smoothed_log = savgol_filter(pred_log, 5, 2) if len(pred_log) >= 5 else pred_log
        with np.errstate(over="ignore"):
            unclipped = 10.0 ** smoothed_log
        profile = np.clip(unclipped, 0.1, 1e4)
        case.update({"postprocessing": "Original Savitzky-Golay window5 order2 in log10 space, then clip [0.1,10000] ohm m",
                     "clipped_layer_count": int(np.sum((unclipped < 0.1) | (unclipped > 1e4))),
                     "predicted_resistivity": profile.tolist(),
                     "layer_midpoints_m": mids.tolist(),
                     "reference_comparison": {
                         "label": "WinGLink ZINV inversion reference; independent truth unavailable",
                         "finite_reference_support_bottom_m": reference_bottom,
                         "support_definition": "Predicted layer midpoints at or above the last reference layer top; arbitrary final display thickness excluded",
                         "sampled_layer_count": int(np.sum(overlap)),
                         "log10_resistivity_rmse": float(np.sqrt(np.mean(
                             np.log10(profile[overlap] / reference_sample) ** 2)))}})
        fit_rho, fit_phi = physics.analytical_forward_model(
            profile, h, 1 / synth["periods"])
        case["forward_fit_to_corrected_measurements"] = {
            component: response_metrics(fit_rho, fit_phi, *curves[component])
            for component in ["corrected_xy", "corrected_det", "corrected_yx"]
            if component in curves}
        case["forward_apparent_resistivity"] = fit_rho.tolist()
        case["forward_phase_deg"] = fit_phi.tolist()
        result["cases"][name] = case
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, default=Path("results/legacy_audit.json"))
    parser.add_argument("--sample-count", type=int, default=16)
    args = parser.parse_args()
    root = args.root.resolve()
    torch.set_num_threads(min(4, torch.get_num_threads()))
    legacy_source = root / "Corrected_DeepLearning_MT_V2.py"
    original = original_definitions(legacy_source)
    synth_path = root / "synthetic_data.pkl"
    with synth_path.open("rb") as stream:
        synth = pickle.load(stream)
    report = {"purpose": "Read-only audit of supplied legacy artifacts; no network training performed",
              "audit_environment": {"python": platform.python_version(),
                                    "packages": {name: importlib.metadata.version(name)
                                                 for name in ["numpy", "scipy", "torch", "scikit-learn"]}},
              "limitations": [
                  "Exact paper training environment, split membership, synthetic-generation version and selected checkpoint are not recorded in supplied artifacts.",
                  "The screenshots attached to the researcher's email differ from the supplied saved prediction plots. Reproduction of those screenshots is not established because their exact weights, scalers, data cache and source revision are unavailable.",
                  "Correcting field units cannot repair training targets or regenerate supplied learned weights.",
                  "Fine-tuned checkpoint filenames are preserved and labeled explicitly; original source trains these on all available field references, which precludes independent validation on those stations.",
                  "Reference metrics use predicted layer midpoints no deeper than the last reference layer top; arbitrary final display thickness is excluded and the last resistivity is a halfspace for forward calculations.",
                  "Normalized response RMS uses illustrative 5 percent apparent-rho / 2 degree phase floors; it is not a likelihood from EDI variances.",
                  "Original prediction smoothing and clipping are retained solely for the baseline; raw output and clip counts are disclosed.",
                  "Original Informer has stochastic attention even in evaluation; seed99 is reset per prediction."],
              "source_provenance": [sha256(legacy_source), sha256(synth_path)],
              "synthetic": audit_synthetic(synth, original, args.sample_count),
              "sites": {}}
    for edi_path in sorted((root / "real_data").glob("*.edi")):
        ref_path = edi_path.with_name(edi_path.stem + "Layered.txt")
        if not ref_path.exists():
            continue
        curves, summary = field_curves(edi_path, synth["periods"], original)
        reference = physics.read_layered_model(ref_path)
        tops, ref_h, ref_rho = reference
        ref_forward = physics.analytical_forward_model(
            ref_rho, ref_h[:-1], 1 / synth["periods"])
        site_report = {"edi_provenance": sha256(edi_path),
                       "reference_provenance": sha256(ref_path),
                       "reference_description": "Supplied layered export declares Curve=ZINV and Rotation=Imported; paper describes WinGLink conventional 1D inversion.",
                       "reference_layer_tops_m": tops.tolist(),
                       "reference_layer_thicknesses_m": ref_h.tolist(),
                       "reference_resistivity": ref_rho.tolist(),
                       "field_inputs": summary,
                       "reference_forward_fit": {
                           k: response_metrics(*ref_forward, *v)
                           for k, v in curves.items() if k.startswith("corrected_")},
                       "checkpoints": {}}
        for model_type in ["lstm", "gru", "informer"]:
            directory = root / "models" / model_type.upper()
            scaler_path = directory / f"{model_type}_scalers.pkl"
            if not scaler_path.exists():
                continue
            with scaler_path.open("rb") as stream:
                scalers = pickle.load(stream)
            for variant, suffix in [("base", ""), ("finetuned", "_finetuned")]:
                checkpoint_path = directory / f"{model_type}_checkpoint{suffix}.pt"
                if not checkpoint_path.exists():
                    continue
                key = f"{model_type}_{variant}"
                try:
                    entry = evaluate_checkpoint(checkpoint_path, scalers, curves,
                                                reference, synth, original)
                    entry["scaler_provenance"] = sha256(scaler_path)
                    entry["training_status"] = (
                        "Supplied synthetic pretrained artifact" if variant == "base"
                        else "Supplied field-reference-finetuned artifact; potentially includes evaluated site")
                    site_report["checkpoints"][key] = entry
                except Exception as error:
                    site_report["checkpoints"][key] = {
                        "provenance": sha256(checkpoint_path),
                        "error": f"{type(error).__name__}: {error}"}
        site_report["base_finetuned_state_identical"] = {
            name: site_report["checkpoints"][f"{name}_base"].get("state_tensor_sha256")
            == site_report["checkpoints"][f"{name}_finetuned"].get("state_tensor_sha256")
            for name in ["lstm", "gru", "informer"]
            if site_report["checkpoints"].get(f"{name}_base", {}).get("state_tensor_sha256")
            and site_report["checkpoints"].get(f"{name}_finetuned", {}).get("state_tensor_sha256")}
        report["sites"][edi_path.stem] = site_report
    destination = args.output if args.output.is_absolute() else root / args.output
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(report, indent=2, allow_nan=False), encoding="utf-8")
    print(f"Legacy audit saved to {destination}")
    print(json.dumps({site: {"reference_forward_fit": detail["reference_forward_fit"],
                            "checkpoint_errors": {name: record.get("error")
                                                  for name, record in detail["checkpoints"].items()
                                                  if record.get("error")}}
                      for site, detail in report["sites"].items()}, indent=2))


if __name__ == "__main__":
    main()
