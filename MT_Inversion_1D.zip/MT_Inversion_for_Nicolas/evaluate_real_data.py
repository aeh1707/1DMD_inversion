"""Evaluate a corrected checkpoint against every EDI file in real_data.

References are used only for scoring. Each site is also predicted without its
reference to check that the neural result is unchanged. No training occurs.
"""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / 'tmp' / 'matplotlib'))

import numpy as np
import torch

from main import predict_site


def fingerprint(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def evaluate(data_dir, checkpoint, output_dir, model_type='gru', component='det'):
    data_dir, checkpoint, output_dir = map(Path, (data_dir, checkpoint, output_dir))
    sites = sorted(data_dir.glob('*.edi'))
    if not sites:
        raise ValueError(f'No EDI files found in {data_dir}')
    output_dir.mkdir(parents=True, exist_ok=True)
    sources = [checkpoint, *sites, *sorted(data_dir.glob('*Layered.txt'))]
    before = {str(path.resolve()): fingerprint(path) for path in sources}
    report = {'checkpoint': str(checkpoint.resolve()), 'component': component,
              'model_type': model_type, 'training_performed': False,
              'reference_role': 'Evaluation only; WinGLink reference is not independent ground truth',
              'response_error_units': {'rho': 'log10 apparent resistivity', 'phase': 'degrees'},
              'sources_sha256': before, 'sites': {}, 'errors': {}}
    rows = []
    for edi in sites:
        reference = edi.with_name(edi.stem + 'Layered.txt')
        reference = reference if reference.is_file() else None
        common = dict(model_type=model_type, component=component, checkpoint=checkpoint)
        try:
            neural = predict_site(edi, reference, output_dir=output_dir, **common)
            independent = predict_site(edi, None, **common)
            np.testing.assert_array_equal(neural.profile, independent.profile)
            np.testing.assert_array_equal(neural.depths, independent.depths)
            refined = predict_site(edi, reference, refine=True, output_dir=output_dir, **common)
            report['sites'][edi.stem] = {
                'reference_independence_and_repeatability_passed': True,
                'neural': neural.diagnostics,
                'neural_plus_physics': refined.diagnostics,
            }
            for result in [neural, refined]:
                d = result.diagnostics
                rows.append({
                    'site': edi.stem, 'method': d['result_type'],
                    'observations': d['n_observations'],
                    'response_log10_rho_rmse': d['response_log10_rho_rmse'],
                    'response_phase_rmse_deg': d['response_phase_rmse_deg'],
                    'reference_log10_rho_rmse': d.get('reference_log10_rho_rmse'),
                    'physics_converged': d.get('physics_fit', {}).get('success'),
                    'feature_max_abs_z': d['metadata'].get('feature_max_abs_z'),
                })
            if not refined.diagnostics['physics_fit']['success']:
                raise RuntimeError('Physics fit did not converge; inspect the saved diagnostics.')
            print(f'{edi.stem}: prediction, reference-independence and physics convergence passed', flush=True)
        except Exception as error:
            report['errors'][edi.stem] = f'{type(error).__name__}: {error}'
            print(f'{edi.stem}: FAILED: {error}', flush=True)
    after = {str(path.resolve()): fingerprint(path) for path in sources}
    report['source_files_unchanged'] = before == after
    report['passed'] = not report['errors'] and report['source_files_unchanged']
    (output_dir / 'evaluation.json').write_text(json.dumps(report, indent=2, allow_nan=False), encoding='utf-8')
    if rows:
        with (output_dir / 'summary.csv').open('w', newline='', encoding='utf-8') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path, default=ROOT / 'real_data')
    parser.add_argument('--checkpoint', type=Path, default=ROOT / 'artifacts' / 'gru_checkpoint.pt')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'results' / 'real_data_test')
    parser.add_argument('--model', choices=['gru', 'lstm', 'informer'], default='gru')
    parser.add_argument('--component', choices=['det', 'xy', 'yx'], default='det')
    args = parser.parse_args()
    torch.set_num_threads(2)
    result = evaluate(args.data_dir, args.checkpoint, args.output_dir, args.model, args.component)
    print(f"Overall: {'PASS' if result['passed'] else 'FAIL'}; results: {args.output_dir}")
    raise SystemExit(0 if result['passed'] else 1)
