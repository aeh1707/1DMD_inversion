# Validation and limitations

## What this bundle establishes

The repaired software runs end to end, passes 26 automated checks and predicts
both supplied field sites without training on their reference models. A new
GRU trained with consistent physics gives the measured-response fits reported
below. These are useful software and pilot-study
results. **They do not establish general field reliability, unique geological
truth, or exact reproduction of the published paper.**

The source project is
[aeh1707/1DMD_inversion](https://github.com/aeh1707/1DMD_inversion). The paper
reviewed in the original folder was *Comparison of deep learning models for
1D magnetotelluric inversion*, `1-s2.0-S2590197426000042-main.pdf`. Changes to
physics, preprocessing, architecture and training make the included results a
new experiment rather than a revision of the paper's reported numbers.

## Defects addressed

1. Standard SEG EDI impedance needed conversion from `(mV/km)/nT` to E/H in
   ohms before computing apparent resistivity. Omitting this inflated
   apparent resistivity by 633,257.3978, approximately 5.80 log10 decades.
   `UNITS=M` in the measurement header did not make those impedances SI.
2. The original forward recurrence mixed signs and gave a 135-degree
   homogeneous half-space phase. A consistent `exp(+i omega t)` convention
   now gives the specified resistivity and +45 degrees.
3. The supplied `predict_model` function returned nothing, while the README
   advertised another function and a different tuple order. Both historical
   orders now work, and `predict_site` provides unambiguous named fields.
4. Depths, layer thicknesses and targets are kept consistent. The surface
   layer starts at zero; the final layer is an infinite half-space.
5. EDI block sizes, frequencies, missing values, checkpoint dimensions and
   interpolation coverage are validated. Extrapolation is rejected.
6. New training never automatically fine-tunes on the field reference models
   used for scoring. Scalers fit training data only, and synthetic test data
   are disjoint from training and validation.

The original cache and checkpoints had additional provenance problems:
sampled cached responses disagreed with the corrected forward solver, base
and named fine-tuned weight tensors were identical, and supplied LSTM
configuration differed from the paper. Correcting input units alone did not
improve every legacy model's reference-profile score. The recorded audit in
`diagnostics/` preserves that evidence; it is not a claim that the legacy
models now reproduce the publication.

## New synthetic experiment

The included GRU used 10,000 independent synthetic models, generation and
split seed 99, 47 resistivity layers and 25 periods from 0.001 to 1000 seconds.
Its hidden sizes were 64/32, dropout 0.1, batch size 128, learning rate 0.001,
and AdamW weight decay 0.00001. Training ran for 80 CPU epochs with two compute
threads, early-stopping patience 12, and the best validation result at epoch
80. Generation and training took 325.19 seconds on the developer's machine;
that is not a runtime guarantee for another computer.

| Subset / result | Value |
|---|---:|
| Training models | 7,000 |
| Validation models | 1,500 |
| Untouched synthetic test models | 1,500 |
| Test log10 resistivity-profile RMSE | 0.46318 |
| Test log10 resistivity-profile MAE | 0.24889 |
| Training-mean-profile baseline test RMSE | 1.31762 |

This shows learning relative to a simple baseline within the chosen
synthetic prior. It does not show the same accuracy on unseen geological
settings. The shipped experiment has noise-free synthetic observations; the
generator supports optional noise, but realistic survey-specific error,
distortion and uncertainty modeling has not been validated here.

Only the GRU underwent this substantive experiment. Small training/inference
checks for LSTM and Transformer do not establish comparable scientific
performance. New `informer` training uses full attention and is not a
replication of the paper's ProbSparse Informer.

## Field evaluation on the supplied `real_data` folder

The table uses determinant impedance and measured periods inside the
checkpoint range. These scores compare each model's **forward MT response**
against observations, not the resistivity profile against known geology.

| Site | Method | Measured periods | Log10 apparent-rho RMSE | Phase RMSE (degrees) | Log10 reference-profile RMSE |
|---|---|---:|---:|---:|---:|
| 3D01 | GRU only | 71 | 0.12812 | 2.63547 | 0.19676 |
| 3D01 | GRU + physics inversion | 71 | 0.01354 | 1.12443 | 0.18770 |
| 3D02 | GRU only | 61 | 0.12357 | 3.36629 | 0.29582 |
| 3D02 | GRU + physics inversion | 61 | 0.03014 | 2.74114 | 0.23436 |

Both physics inversions converged. Repeated neural predictions were identical,
removing reference files from prediction left the neural profiles unchanged,
and hashes confirmed that the checkpoint and source field data were unchanged.
Exact values, convergence messages and metadata are in
`results/real_data_test/evaluation.json` and the individual metrics files.

The reference profiles are WinGLink inversion estimates, **not known ground
truth**. Reference-profile RMSE uses predicted layer midpoints within the
tabulated reference depth range and stepwise reference sampling. It does not
score an arbitrarily extended reference half-space as known deep geology.
Determinant impedance was selected because the references identify
`Curve="ZINV"` and their forward responses agree with determinant data more
closely than with individual XY or YX modes. This interpretation is an
inference; alternate modes remain selectable.

The GRU captures the conductive trough but still overestimates shallow
resistivity at 3D02 and has imperfect long-period response fit. The two sites
were not used as training labels. They are nevertheless only **two supplied
examples**, not a broad independent benchmark.

The physics inversion directly fits the same observations used to report
its error. It uses a smoothness penalty on first differences of log10
resistivity, bounds of 0.01–100,000 ohm metres, and fixed illustrative error
floors of 0.05 log10 apparent resistivity and 3 degrees. Those are not measured
uncertainties. A lower final misfit demonstrates that this conventional fit
can match the measured curves; it does not demonstrate that the neural
network alone is that accurate. Smoothness, bounds and starting model can
affect the resulting depth profile.

## What to verify before other-data use

- Confirm a plausible 1D approximation and consistent impedance units,
  component orientation and phase convention. Lateral structure, static
  shift and out-of-distribution responses can impair a result.
- Cover the entire checkpoint period grid. The included checkpoint requires
  0.001–1000 seconds. Shorter coverage requires a suitably redesigned and
  retrained model; silent extrapolation is not supported.
- Match the training prior, depth scale, resistivity range and noise to the
  intended survey. Changing them requires consistent synthetic generation,
  retraining and new validation; arbitrary checkpoint edits are invalid.
- Preserve genuinely independent sites for evaluation. Do not report scores
  on reference models used for tuning as independent performance.
- Inspect apparent-resistivity and phase residuals, physics convergence,
  independent inversion comparisons, noise sensitivity and depth resolution.
  The present code does not provide calibrated uncertainty intervals or a
  validated depth-of-investigation estimate.

MT inversion is nonunique. Similar measured responses can arise from
different depth profiles, especially in poorly resolved shallow or deep
regions. Neither a small response misfit nor agreement with another inversion
selects a uniquely correct earth model.

## What Nicolas can reasonably expect

The bundle resolves the return-order/API confusion, supplies a consistent
physics and preprocessing path, includes a trained checkpoint, and makes the
two-site evaluation repeatable. Those directly address the practical issues
in his email. Whether it satisfies his scientific purpose depends on his
rerun, data and required accuracy; acceptance cannot be promised.

To reproduce the paper exactly, obtain the original training revision and
environment, data-generation/noise procedure, split membership, model
selection and exact weights/scalers used for each published figure. The
repair cannot recover these from filenames or screenshots. Further field
validation should include independent surveys, realistic noise/distortion
tests, conventional baselines and uncertainty/resolution analysis.

Background on these limits is available in the
[SimPEG 1D MT inversion example](https://wiki.seg.org/wiki/Exploring_nonlinear_inversions%3A_A_1D_magnetotelluric_example)
and Google's explanation of
[generalization and overfitting](https://developers.google.com/machine-learning/crash-course/overfitting/overfitting).
